# USER_MANUAL.md
**Project:** doxstrux Refactor Phases
**Applies to:** `DETAILED_TASK_LIST_template.yaml / .json / .md`
**Audience:** Human contributors • AI agents • CI pipelines
**Purpose:** Explain how the detailed task list acts as a reusable plan container, how to author and validate it, and how to convert prose refactor briefs into the structured formats enforced by CI.

---

## 1. Overview
- The refactor plan lives in **three synchronized artifacts** that must always be rendered from the same YAML source:
  | Format | Editable? | Primary consumers | Purpose |
  |:--|:--|:--|:--|
  | `DETAILED_TASK_LIST_template.yaml` | ✅ Yes (single source of truth) | Humans & AI | Canonical plan definition |
  | `DETAILED_TASK_LIST_template.json` | ❌ Generated | AI agents & CI | Strict schema-conformant execution plan |
  | `DETAILED_TASK_LIST_template.md` | ❌ Generated | Reviewers & stakeholders | Human-friendly narrative view |
- Rendering is performed with `python tools/render_task_templates.py --strict` which aborts on validation failures (see §6).
- All downstream automation (pre-commit, CI, AI task runners) reads from the generated JSON.

---

## 2. Repository layout (relevant files)
```
.
├── DETAILED_TASK_LIST_template.yaml      # editable template
├── DETAILED_TASK_LIST_template.json      # renderer output
├── DETAILED_TASK_LIST_template.md        # renderer output
├── USER_MANUAL.md                        # this guide
├── tools/
│   ├── render_task_templates.py          # renderer + validators
│   ├── validate_task_ids.py              # ID monotonicity/uniqueness checks
│   ├── validate_commands.py              # command deny/allow list enforcement
│   ├── sanitize_paths.py                 # ensures repo-relative POSIX paths
│   └── ...                               # helper scripts referenced in the schema
├── schemas/
│   ├── detailed_task_list.schema.json    # schema v2.0.0 (authoritative contract)
│   └── CHANGELOG.md                      # schema evolution notes
├── evidence/                             # execution logs & manifests
└── .github/workflows/verify_render.yml   # CI render + schema validation pipeline
```

---

## 3. Authoring rules (humans)
1. **Edit only the YAML template.** JSON/MD are regenerated artifacts and must not be hand-edited.
2. Use the existing `TBD_…` placeholders while drafting. Rendering with `--strict` will fail if any `{{…}}` placeholder remains.
3. Keep indentation to two spaces per nesting level and leave a blank line between logical sections for readability.
4. Task IDs must remain monotonically increasing strings (`0.0`, `0.1`, `1.0`, …). Do not reorder existing IDs; append new decimal suffices when inserting tasks.
5. All lists (`acceptance_criteria`, `steps`, `ci_gates`, etc.) must stay as YAML arrays. Multiline strings are prohibited because they break JSON round-tripping.
6. File references must be POSIX-relative to the repository root. If in doubt, run `python tools/sanitize_paths.py` before committing.

---

## 4. Schema v2.0.0 map (top-level keys)
| Key | Description | Notes |
|:--|:--|:--|
| `schema_version` | Semantic version of the template contract | Must be `2.0.0` for the current schema |
| `document` | Identifies the plan (`id`, `title`, `version`, `created`, `owner`, `audience`) | All values must be non-empty strings with no `{{…}}` placeholders |
| `metadata` | Project-wide facts (`project_full_name`, goal, status, totals, schema echo) | `schema_version` inside this block is auto-synced by the renderer |
| `success_criteria` | High-level definition of success for the entire refactor | List of short, affirmative statements |
| `phase_unlock_mechanism` | Rules and validation command for phase completion artifacts | Includes embedded schema describing `.phase-N.complete.json` |
| `environment_variables` | Required runtime configuration for scripts/commands | Each entry lists `name`, `description`, and default |
| `global_utilities` | Reusable helper scripts (timeout helper, atomic write, etc.) | All files must exist in repo and use forward slashes |
| `test_macros` | Canonical command shorthands (fast/full/performance tests, CI sequence) | Enables renderers & agents to expand consistent commands |
| `corpus_metadata` | Snapshot of corpus layout for reproducible validation | Guides agents on dataset expectations |
| `performance_thresholds` | Policy references and metrics caps | Keeps regression checks auditable |
| `git_macros` | Common git commands for checkpoints/tags/rollback | Used by rollback procedures |
| `ci_gates` | Ordered list of CI gates (`G1…Gn`) with commands and remediation hints | Gates must remain sequential and unique |
| `core_principle` & `testing_strategy` | Narrative guardrails for execution | Supports agent explainability |
| `phases` | Dictionary of phases (`phase_0`, `phase_template`, etc.) containing task arrays | Each task lists `steps`, `acceptance_criteria`, status, and optional references |
| `phase_completion` | Checklist, validation commands, and reporting expectations before unlocking the next phase | Feeds completion artifact generation |
| `rollback_procedures` | Standard operating procedures for common failure modes | Each entry defines named steps (commands + descriptions) |
| `progress_tracking` | File and column structure for recording progress metrics | Enables consistent dashboards |
| `template_metadata` | Renderer bookkeeping (generator, timestamps, command) | Renderer updates `last_rendered_utc` automatically |
| `render_meta` (JSON/MD only) | Hash + timestamp proof linking rendered artifacts back to YAML | Generated automatically; never edit manually |

---

## 5. Phase and task structure
- `phases` is an object keyed by phase identifiers (e.g., `phase_0`, `phase_template`). Each phase includes:
  - `name`, `goal`, `time_estimate`, `status`, and optional prerequisites.
  - `tasks`: array of objects with fields `id`, `name`, `time_estimate`, `files`, `test`, optional `references`, `steps` (ordered list), `acceptance_criteria` (list), and `status`.
- Task steps should be actionable imperative sentences. Acceptance criteria must be objectively verifiable checks.
- Keep time estimates and references concise (`TBD_…` placeholders are acceptable while drafting but must be replaced before execution).

---

## 6. Rendering & validation pipeline
Running `python tools/render_task_templates.py --strict` performs the following:
1. Parses YAML and resolves environment variables (including `.env` files if present).
2. Invokes auxiliary validators:
   - `tools/validate_task_ids.py` for numeric ordering and uniqueness across all nested tasks.
   - `tools/validate_commands.py` to block unsafe shell constructs and enforce the command policy.
   - `tools/sanitize_paths.py` to guarantee repo-relative POSIX paths and reject absolute locations.
3. Renders synchronized JSON and Markdown outputs.
4. Validates the JSON against `schemas/detailed_task_list.schema.json` (draft 2020-12).
5. Injects `render_meta` containing the YAML SHA256, source filename, schema version, and render timestamp into JSON/MD.
6. Fails fast if any placeholders (`{{…}}`) or validator errors remain.

**Dependencies:** Install with `pip install -r requirements.txt` (PyYAML + jsonschema). The sandbox environment used for CI already has these packages available.

---

## 7. Pre-commit & CI enforcement
- `.pre-commit-config.yaml` runs the renderer in strict mode, the path sanitizer, and placeholder scans before allowing commits.
- `.github/workflows/verify_render.yml` executes on every pull request:
  1. Installs dependencies (`pip install -r requirements.txt`).
  2. Runs the renderer with `--strict`.
  3. Validates the freshly rendered JSON against the schema (using `Draft202012Validator`).
  4. Diff-checks JSON/MD to ensure the committed versions match the rendered output.
  5. Surfaces validation errors inline, blocking merges on any drift.
- CI also prepares the environment for evidence generation and ensures gate commands stay deterministic.

---

## 8. Turning prose into the structured template (plan container workflow)
Use this pipeline to transform a free-form refactor brief (e.g., `docs/DOXSTRUX_REFACTOR.md`) into the YAML template:
1. **Semantic parsing (text → task candidates)**
   ```python
   def extract_tasks_from_doc(text):
       sections = split_by_patterns(text, patterns=[r"^#+", r"Step\s+\d", r"\d+\.\d"])  # headers, numbered steps
       for idx, sec in enumerate(sections):
           yield {
               "id": f"{current_phase}.{idx}",
               "name": infer_title(sec),                    # imperative verb + noun
               "kind": classify_kind(sec),                  # code_change / test_change / doc_change / ops
               "impact": infer_impact(sec),                 # map "critical" → P0, etc.
               "command_sequence": extract_commands(sec),   # shell/code fences
               "acceptance_criteria": extract_criteria(sec) # sentences containing verify/ensure/accept
           }
   ```
   - Lightweight NLP (regex, spaCy, or an LLM prompt) is sufficient—focus on imperative verbs and verification phrases.

2. **Schema builder (task candidates → validated YAML)**
   ```python
   from jsonschema import validate
   import yaml, json

   SCHEMA = json.load(open("schemas/detailed_task_list.schema.json"))
   tasks = list(extract_tasks_from_doc(Path("docs/DOXSTRUX_REFACTOR.md").read_text()))
   yaml_obj = {
       "schema_version": "2.0.0",
       "document": {...},
       "metadata": {...},
       "phases": {"phase_0": {"tasks": tasks, ...}},
       "ci_gates": [...],
       # populate remaining top-level keys as required
   }
   validate(instance=yaml_obj, schema=SCHEMA)
   Path("DETAILED_TASK_LIST_generated.yaml").write_text(
       yaml.safe_dump(yaml_obj, sort_keys=False)
   )
   ```
   - Always fill required metadata before validation. Leave placeholders prefixed with `TBD_` if values are pending human review.

3. **Rendering & round-trip validation**
   ```bash
   python tools/render_task_templates.py --source DETAILED_TASK_LIST_generated.yaml --strict
   ```
   - Produces synchronized JSON/MD, injects `render_meta`, and repeats schema validation.
   - Follow with `git diff --exit-code` to confirm renders are committed.

**Optional AI-assisted flow:** Prompt an LLM as “task extractor” with instructions to output YAML conforming to the schema (imperative task names, list-form acceptance criteria, P1 default impact). Feed the result through steps 2–3 so the renderer and CI lint the output automatically.

---

## 9. Execution guidance for AI agents & humans
- Agents should consume the JSON artifact:
  1. Read `document` and `metadata` for context and reporting requirements.
  2. Prepare environment variables listed under `environment_variables.required`.
  3. Use `global_utilities`, `test_macros`, and `git_macros` for consistent command invocations.
  4. Execute phase tasks in order; mark status updates in the evidence logs, not in the template.
  5. After completing phase tasks, run the `ci_gates` commands sequentially and record outcomes.
  6. Generate the `.phase-N.complete.json` artifact following `phase_unlock_mechanism.artifact_schema` and `phase_completion` checklist.
  7. Apply `rollback_procedures` immediately on failure conditions and capture evidence in `evidence/`.
- Humans oversee ambiguous decisions, approve completion artifacts, and update the YAML when scope changes.

---

## 10. Evidence & reproducibility
- Store execution logs, screenshots, metrics, and completion artifacts in `evidence/` (see `evidence/README.md` for manifest expectations).
- Record every CI gate run and task result with timestamps and hashes to support audits.
- Maintain an `index.json` manifest mapping `task_id` → evidence payload once the automation layer is in place.

---

## 11. Quick reference commands
| Action | Command |
|:--|:--|
| Install tooling | `pip install -r requirements.txt` |
| Render JSON & Markdown | `python tools/render_task_templates.py --strict` |
| Schema-check committed JSON | `python - <<'PY' ...` (see CI step in §7) |
| Validate task IDs manually | `python tools/validate_task_ids.py` |
| Validate command safety manually | `python tools/validate_commands.py` |
| Sanitize file paths | `python tools/sanitize_paths.py` |
| Regenerate renders & confirm no drift | `python tools/render_task_templates.py --strict && git diff --stat` |

---

## 12. Versioning policy
- Bump `schema_version` only when `schemas/detailed_task_list.schema.json` changes.
- Document schema updates in `schemas/CHANGELOG.md`.
- Always re-render JSON/MD after updating the YAML or schema to keep `render_meta` accurate.

End of USER_MANUAL.md
