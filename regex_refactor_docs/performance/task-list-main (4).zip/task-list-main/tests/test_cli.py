from pathlib import Path

from tasklist import render_task_templates, validate_task_ids


def test_render_and_validate(tmp_path):
    repo_yaml = Path("DETAILED_TASK_LIST_template.yaml")
    target_yaml = tmp_path / repo_yaml.name
    target_yaml.write_text(repo_yaml.read_text(encoding="utf-8"), encoding="utf-8")

    # Render into the temporary directory
    exit_code = render_task_templates.main(["--strict", "--root", str(tmp_path)])
    assert exit_code == 0

    rendered_json = tmp_path / "DETAILED_TASK_LIST_template.json"
    assert rendered_json.exists()

    # Validate IDs using the generated JSON
    exit_code = validate_task_ids.main(["--root", str(tmp_path)])
    assert exit_code == 0
