#!/usr/bin/env python3
"""Render the detailed task list template into JSON and Markdown outputs."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from datetime import datetime, timezone
from importlib import resources as importlib_resources
from pathlib import Path
from typing import Sequence

import yaml
from jsonschema import validate
from jsonschema.exceptions import ValidationError

from tasklist.validate_commands import validate_commands
from tasklist.validate_task_ids import (
    validate_acceptance_criteria,
    validate_gate_ids,
    validate_task_ids,
)
from tasklist.sanitize_paths import validate_artifact_paths, validate_task_file_paths

DEFAULT_SOURCE_NAME = "DETAILED_TASK_LIST_template.yaml"
DEFAULT_JSON_NAME = "DETAILED_TASK_LIST_template.json"
DEFAULT_MD_NAME = "DETAILED_TASK_LIST_template.md"
DEFAULT_HASH_DIR = Path("evidence") / "hashes"
PLACEHOLDER_PATTERN = re.compile(r"\{\{([^{}]+)\}\}")


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def compute_sha256(file_path: Path) -> str:
    """Compute the SHA256 hash of ``file_path``."""
    with file_path.open("rb") as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def expand_placeholders(data: str, strict: bool = False) -> str:
    """Replace ``{{VAR}}`` placeholders with environment or .env values."""

    def repl(match: re.Match[str]) -> str:
        var = match.group(1).strip()
        val = os.getenv(var)
        if val is None and strict:
            raise ValueError(f"Unresolved placeholder: {{{{{var}}}}}")
        return val or match.group(0)

    return PLACEHOLDER_PATTERN.sub(repl, data)


def load_env_file(root: Path) -> None:
    """Populate ``os.environ`` with values from ``root/.env`` if present."""
    env_path = root / ".env"
    if not env_path.exists():
        return

    with env_path.open(encoding="utf-8") as handle:
        for line in handle:
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                continue
            if "=" not in stripped:
                continue
            key, value = stripped.split("=", 1)
            os.environ.setdefault(key, value)


def add_render_meta(data: dict, yaml_path: Path, root: Path | None) -> dict:
    """Attach ``render_meta`` information to the rendered task list."""
    meta = data.setdefault("render_meta", {})
    source_path: Path | str = yaml_path
    if root is not None:
        try:
            source_path = yaml_path.relative_to(root)
        except ValueError:
            source_path = yaml_path
    meta.update(
        {
            "source_file": str(source_path),
            "schema_version": data.get("schema_version", "1.0.0"),
            "sha256_of_yaml": compute_sha256(yaml_path),
            "rendered_utc": _utc_now(),
        }
    )
    return data


def yaml_to_json(yaml_path: Path, strict: bool, root: Path | None) -> dict:
    """Load ``yaml_path`` and return the expanded Python dictionary."""
    raw_text = yaml_path.read_text(encoding="utf-8")
    expanded = expand_placeholders(raw_text, strict=strict)
    data = yaml.safe_load(expanded)

    template_meta = data.setdefault("template_metadata", {})
    template_meta["last_rendered_utc"] = _utc_now()

    metadata_block = data.get("metadata")
    if isinstance(metadata_block, dict):
        metadata_block.setdefault("schema_version", data.get("schema_version", "1.0.0"))

    return add_render_meta(data, yaml_path, root)


def _schema_resource():
    return importlib_resources.files("tasklist.schemas").joinpath("detailed_task_list.schema.json")


def validate_json(data: dict) -> None:
    """Validate ``data`` against the packaged JSON schema."""
    with importlib_resources.as_file(_schema_resource()) as schema_path:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
    try:
        validate(instance=data, schema=schema)
    except ValidationError as exc:  # pragma: no cover - exercised in CI
        sys.stderr.write(f"[ERROR] JSON schema validation failed:\n{exc}\n")
        sys.exit(1)


def render_markdown(data: dict) -> str:
    """Render a Markdown summary of the rendered task list."""
    lines: list[str] = []
    document = data.get("document", {})
    metadata = data.get("metadata", {})
    render_meta = data.get("render_meta", {})

    lines.append("---")
    lines.append(f"title: \"Detailed Task List - {document.get('title', 'Untitled')}\"")
    lines.append(f"version: \"{document.get('version', '1.0')}\"")
    lines.append(f"schema_version: \"{data.get('schema_version', '1.0.0')}\"")
    lines.append(f"document_id: \"{document.get('id', 'Unknown')}\"")
    lines.append(f"created: \"{document.get('created', 'Unknown')}\"")
    lines.append(f"owner: \"{document.get('owner', 'Unknown')}\"")
    lines.append("audience:")
    for member in document.get("audience", []):
        lines.append(f"  - {member}")
    lines.append("metadata:")
    lines.append(f"  project_full_name: \"{metadata.get('project_full_name', 'Unknown')}\"")
    lines.append(f"  status: \"{metadata.get('status', 'Unknown')}\"")
    lines.append(f"  total_phases: {metadata.get('total_phases', '0')}")
    lines.append(
        f"  schema_version: \"{metadata.get('schema_version', data.get('schema_version', '1.0.0'))}\""
    )
    lines.append("---")
    lines.append("")

    lines.append(f"# Detailed Task List — {document.get('title', 'Untitled')}")
    lines.append(f"Generated: {render_meta.get('rendered_utc', 'Unknown')}")
    lines.append("")

    project_goal = metadata.get("project_goal")
    if project_goal:
        lines.append("## Project Goal")
        lines.append(project_goal)
        lines.append("")

    for phase_name, phase in sorted(data.get("phases", {}).items()):
        if not isinstance(phase, dict):
            continue
        lines.append(f"## {phase_name}: {phase.get('name', 'Unnamed Phase')}")
        goal = phase.get("goal")
        if goal:
            lines.append(goal)
            lines.append("")
        tasks = phase.get("tasks", [])
        if tasks:
            lines.append("| ID | Name | Kind | Impact | Status | Acceptance Criteria |")
            lines.append("| --- | --- | --- | --- | --- | --- |")
            for task in tasks:
                if not isinstance(task, dict):
                    continue
                lines.append(
                    "| {id} | {name} | {kind} | {impact} | {status} | {criteria} |".format(
                        id=task.get("id", "?"),
                        name=task.get("name", "Unnamed"),
                        kind=task.get("kind", "?"),
                        impact=task.get("impact", "?"),
                        status=task.get("status", ""),
                        criteria=", ".join(task.get("acceptance_criteria", [])),
                    )
                )
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("**Render Metadata**:")
    lines.append(f"- Source: `{render_meta.get('source_file', 'Unknown')}`")
    lines.append(f"- Schema: `{render_meta.get('schema_version', 'Unknown')}`")
    lines.append(f"- YAML SHA256: `{render_meta.get('sha256_of_yaml', 'Unknown')}`")
    lines.append(f"- Rendered: `{render_meta.get('rendered_utc', 'Unknown')}`")
    lines.append("")
    lines.append("_End of auto-generated Markdown summary_")
    return "\n".join(lines)


def write_hashes(root: Path, yaml_path: Path, json_path: Path, md_path: Path) -> None:
    """Write SHA256 hashes to ``root/evidence/hashes``."""
    hash_dir = root / DEFAULT_HASH_DIR
    hash_dir.mkdir(parents=True, exist_ok=True)

    (hash_dir / "yaml_sha256.txt").write_text(compute_sha256(yaml_path))
    (hash_dir / "json_sha256.txt").write_text(compute_sha256(json_path))
    (hash_dir / "md_sha256.txt").write_text(compute_sha256(md_path))
    print(f"[OK] Hashes written → {hash_dir.relative_to(root)}")


def print_metadata(root: Path, yaml_path: Path, json_path: Path, md_path: Path) -> None:
    """Print metadata and hash information for the current task list."""
    data = yaml_to_json(yaml_path, strict=False, root=root)

    print("📊 Task List Metadata")
    print("=" * 60)
    print(f"Schema Version: {data.get('schema_version', 'Unknown')}")
    document = data.get("document", {})
    print(f"Document ID: {document.get('id', 'Unknown')}")
    print(f"Title: {document.get('title', 'Unknown')}")
    print(f"Owner: {document.get('owner', 'Unknown')}")
    print()
    print("📁 File Hashes (SHA256)")
    print(f"  YAML: {compute_sha256(yaml_path)}")
    if json_path.exists():
        print(f"  JSON: {compute_sha256(json_path)}")
    if md_path.exists():
        print(f"  MD:   {compute_sha256(md_path)}")
    print()
    print(f"🕒 Last Rendered: {data.get('render_meta', {}).get('rendered_utc', 'Never')}")
    print("=" * 60)


def _display_path(path: Path, root: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Render YAML → JSON + Markdown for refactor tasks",
    )
    parser.add_argument("--strict", action="store_true", help="Fail on unresolved {{VAR}} placeholders")
    parser.add_argument("--meta", action="store_true", help="Print metadata and hashes and exit")
    parser.add_argument("--root", help="Repository root (defaults to current working directory)")
    parser.add_argument("--source", help=f"Source YAML path (default: {DEFAULT_SOURCE_NAME})")
    parser.add_argument("--json-out", help=f"JSON output path (default: {DEFAULT_JSON_NAME})")
    parser.add_argument("--md-out", help=f"Markdown output path (default: {DEFAULT_MD_NAME})")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    root = Path(args.root).resolve() if args.root else Path.cwd()

    def resolve_path(value: str | None, default_name: str) -> Path:
        if value:
            candidate = Path(value)
            if not candidate.is_absolute():
                candidate = (root / candidate).resolve()
            return candidate
        return (root / default_name).resolve()

    source_path = resolve_path(args.source, DEFAULT_SOURCE_NAME)
    json_path = resolve_path(args.json_out, DEFAULT_JSON_NAME)
    md_path = resolve_path(args.md_out, DEFAULT_MD_NAME)

    load_env_file(root)

    if args.meta:
        print_metadata(root, source_path, json_path, md_path)
        return 0

    print(f"[INFO] Rendering {_display_path(source_path, root)}")

    data = yaml_to_json(source_path, strict=args.strict, root=root)

    validation_errors: list[str] = []
    validation_errors.extend(validate_task_ids(data))
    validation_errors.extend(validate_acceptance_criteria(data))
    validation_errors.extend(validate_gate_ids(data))
    validation_errors.extend(validate_commands(data))
    validation_errors.extend(validate_artifact_paths(data))
    validation_errors.extend(validate_task_file_paths(data))

    if validation_errors:
        for err in validation_errors:
            sys.stderr.write(f"{err}\n")
        return 1

    json_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[OK] JSON written → {_display_path(json_path, root)}")

    validate_json(data)
    with importlib_resources.as_file(_schema_resource()) as schema_path:
        print(f"[OK] Schema validated against {_display_path(schema_path, root)}")

    md_text = render_markdown(data)
    md_path.write_text(md_text, encoding="utf-8")
    print(f"[OK] Markdown summary written → {_display_path(md_path, root)}")

    write_hashes(root, source_path, json_path, md_path)

    print("[DONE] Render completed successfully.")
    return 0


if __name__ == "__main__":  # pragma: no cover - CLI entry point
    sys.exit(main())
