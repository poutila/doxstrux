"""Packaged JSON Schemas for task list tooling."""

__all__ = [
    "detailed_task_list_schema",
    "task_result_schema",
]
