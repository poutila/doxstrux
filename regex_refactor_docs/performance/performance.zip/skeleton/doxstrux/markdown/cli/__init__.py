"""CLI tools for debugging and analysis."""
