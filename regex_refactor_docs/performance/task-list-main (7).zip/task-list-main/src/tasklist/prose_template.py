"""Utilities for working with prose refactor briefs."""

from __future__ import annotations

import re
from textwrap import dedent
from typing import Dict, List, Union

__all__ = ["get_template", "check_against_template"]


def get_template() -> str:
    """Return the canonical Markdown template for authoring refactor briefs."""
    return dedent(
        """\
        # <Project or Component> — Refactor Brief

        ## Context
        - Why this refactor is needed.
        - Constraints (performance, deadlines, technical debt, dependencies).

        ## Goals / Non-Goals
        - **Goals**
          - Goal 1 …
          - Goal 2 …
        - **Non-Goals**
          - Not in scope …

        ## Risks & Mitigations
        - Risk: …
        - Mitigation: …

        ## Phase 0 — <Title>
        **Time estimate:** 0.5 d
        **Success criteria:**
        - <measurable result>
        - <measurable result>

        ### Step 1: <Imperative verb + noun>
        Rationale: <why this step is needed>
        Expected artifacts: <files or modules affected>

        ```bash
        # example commands or invocations
        python -m package.module --flag
        ```
        Verify: <clear acceptance statement starting with “verify/ensure/assert”>

        ## Phase 1 — <Title>
        **Time estimate:** 1 d
        **Success criteria:**
        - …

        ### Step 1: …
        Rationale: …
        Expected artifacts: …

        ```bash
        # example commands or invocations
        ```
        Verify: …

        ---
        **Author:** TBD_NAME
        **Last updated:** TBD_UTC
        **Review checklist:**
        - [ ] Steps use imperative verbs
        - [ ] Each phase has measurable success criteria
        - [ ] Commands are fenced in ```bash```/```python``` blocks
        - [ ] At least one “Verify:” line per step
        - [ ] No confidential info or credentials
        """
    )


def check_against_template(prose: str) -> Dict[str, Union[bool, List[str]]]:
    """Check a prose refactor brief against the expected structural template."""

    errors: List[str] = []

    required_sections = [
        r"^# .+Refactor Brief",
        r"^## Context",
        r"^## Goals / Non-Goals",
        r"^## Risks & Mitigations",
        r"^## Phase 0",
    ]
    for pattern in required_sections:
        if not re.search(pattern, prose, flags=re.MULTILINE):
            errors.append(f"Missing section matching: {pattern}")

    if not re.search(r"^###\s*Step\s*\d+", prose, flags=re.IGNORECASE | re.MULTILINE):
        errors.append("No '### Step N:' headings found.")

    step_pattern = re.compile(
        r"^###.*?(?=^###|\Z)", re.IGNORECASE | re.MULTILINE | re.DOTALL
    )
    for index, block in enumerate(step_pattern.findall(prose), start=1):
        if not re.search(r"^\s*verify[:\s]", block, flags=re.IGNORECASE | re.MULTILINE):
            errors.append(f"Step {index} missing a 'Verify:' line.")

    if not re.search(r"```(?:bash|sh|python)?\n.+?\n```", prose, flags=re.DOTALL):
        errors.append("No fenced code block (```bash or ```python) found.")

    phase0_match = re.search(
        r"^##\s*Phase\s*0.*?(?=^##|\Z)", prose, flags=re.IGNORECASE | re.MULTILINE | re.DOTALL
    )
    if phase0_match:
        phase0_block = phase0_match.group(0)
        if "Time estimate" not in phase0_block:
            errors.append("Phase 0 missing 'Time estimate:' line.")
        if "Success criteria" not in phase0_block:
            errors.append("Phase 0 missing 'Success criteria:' section.")
    else:
        errors.append("Phase 0 section not found.")

    return {"ok": not errors, "errors": errors}
