.
[__proto__]

[__proto__]: blah
.
<p><a href="blah"><strong>proto</strong></a></p>
.


.
[hasOwnProperty]

[hasOwnProperty]: blah
.
<p><a href="blah">hasOwnProperty</a></p>
.
