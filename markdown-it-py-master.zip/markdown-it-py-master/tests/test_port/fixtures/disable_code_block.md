indent paragraph
.
    This is a paragraph,
    with multiple lines.

    This paragraph
has variable indents,
      like this.
.
<p>This is a paragraph,
with multiple lines.</p>
<p>This paragraph
has variable indents,
like this.</p>
.

indent in HTML
.
<div>

    Paragraph

</div>
.
<div>
<p>Paragraph</p>
</div>
.

indent fence
.
        ```python
        def foo():
            pass
        ```
.
<pre><code class="language-python">def foo():
    pass
</code></pre>
.

indent heading
.
     # Heading
.
<h1>Heading</h1>
.

indent table
.
     | foo | bar |
     | --- | --- |
     | baz | bim |
.
<table>
<thead>
<tr>
<th>foo</th>
<th>bar</th>
</tr>
</thead>
<tbody>
<tr>
<td>baz</td>
<td>bim</td>
</tr>
</tbody>
</table>
.
