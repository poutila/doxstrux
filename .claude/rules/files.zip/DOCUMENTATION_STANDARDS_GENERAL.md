# Documentation Standards — DOC-001 (Project Rule)

This project requires comprehensive, accurate documentation that serves as the single source of truth for understanding code behavior and contracts.

> **Hard rule:**  
> - All public APIs must have docstrings.  
> - Docstrings must document parameters, return values, and exceptions.  
> - Code should be self-documenting; comments explain **why**, not **what**.  
> - Documentation must stay synchronized with code (tested or enforced).

---

## Classification

- **Category:** Documentation / Maintainability
- **Severity:** ERROR
- **Scope:** All public code; recommended for complex internals
- **Enforceability:** Automated (linting) + Code Review

---

## 1. Goals

- **Clarity:** Anyone reading the code can understand its purpose and usage
- **Maintainability:** Changes require updating documentation, preventing drift
- **Onboarding:** New developers can understand the codebase quickly
- **API Contracts:** Users know what to expect from functions and classes

This rule complements:
- **Type Checking:** Docstrings + type hints = complete contract
- **TDD Governance:** Tests verify behavior; docs describe it
- **Clean Table Principle:** Outdated docs are impurities

---

## 2. Docstring Requirements

### 2.1 Where Docstrings are Required

**MUST have docstrings:**
- All public modules
- All public classes
- All public functions and methods
- All public constants (module-level)

**SHOULD have docstrings:**
- Complex internal functions (>20 lines or complexity >5)
- Non-obvious algorithms or business logic
- Private classes and methods when behavior is not obvious

**MAY skip docstrings:**
- Obvious property getters/setters
- Simple private helpers (when name is self-explanatory)
- Test functions (though encouraged)

### 2.2 Docstring Style

This project uses **Google-style docstrings** (alternative: NumPy style).

**Why Google style:**
- Most readable in source code
- Well supported by tools (Sphinx, PyCharm, VS Code)
- Clear section structure

**Format:**
```python
def function_name(param1: Type1, param2: Type2) -> ReturnType:
    """One-line summary (imperative mood).
    
    Optional longer description that provides more context,
    explains the purpose, and describes behavior.
    
    Args:
        param1: Description of first parameter
        param2: Description of second parameter
    
    Returns:
        Description of return value
    
    Raises:
        ExceptionType: When and why this exception is raised
        AnotherException: When this other exception is raised
    
    Example:
        >>> result = function_name("value1", 42)
        >>> print(result)
        expected output
    
    Note:
        Additional notes or important information
    """
```

---

## 3. Module Docstrings

Every Python module (file) MUST have a module docstring:

**✅ CORRECT:**
```python
"""User authentication and authorization services.

This module provides functions for:
- User login and session management
- Permission checking
- Token generation and validation

Example:
    >>> from myproject.auth import authenticate_user
    >>> user = authenticate_user("alice@example.com", "password123")
    >>> if user.is_authenticated:
    ...     print("Login successful")
"""

import hashlib
from typing import Optional

# ... rest of module
```

**Module docstring should include:**
- Purpose of the module (1-2 sentences)
- Main functionality or classes exported
- Optional: Usage example
- Optional: Important notes or warnings

---

## 4. Class Docstrings

All public classes MUST have docstrings:

**✅ CORRECT:**
```python
class DataProcessor:
    """Process and transform data from various sources.
    
    This class handles loading, validating, and transforming data
    from CSV, Parquet, and JSON sources. It maintains a cache of
    processed results for performance.
    
    Attributes:
        cache_enabled: Whether to use caching (default: True)
        max_cache_size: Maximum number of cached results (default: 1000)
    
    Example:
        >>> processor = DataProcessor(cache_enabled=True)
        >>> data = processor.load_from_csv("data.csv")
        >>> processed = processor.transform(data)
    """
    
    def __init__(self, cache_enabled: bool = True, max_cache_size: int = 1000):
        """Initialize the data processor.
        
        Args:
            cache_enabled: Enable result caching
            max_cache_size: Maximum cache entries
        """
        self.cache_enabled = cache_enabled
        self.max_cache_size = max_cache_size
        self._cache: dict[str, Any] = {}
```

**Class docstring should include:**
- Purpose and responsibility (1-2 sentences)
- Key functionality overview
- Public attributes (if any)
- Optional: Usage example
- Optional: Thread safety, performance notes

---

## 5. Function/Method Docstrings

All public functions and methods MUST have docstrings:

**✅ CORRECT - Complete example:**
```python
def calculate_seasonal_cop(
    heating_output_kwh: float,
    electrical_input_kwh: float,
    outdoor_temp_avg: float
) -> float:
    """Calculate Seasonal Coefficient of Performance (SCOP).
    
    SCOP measures the average efficiency of a heat pump over a heating
    season, accounting for varying outdoor temperatures. Higher values
    indicate better efficiency.
    
    Args:
        heating_output_kwh: Total heating energy delivered in kWh
        electrical_input_kwh: Total electrical energy consumed in kWh
        outdoor_temp_avg: Average outdoor temperature in °C
    
    Returns:
        SCOP value (dimensionless ratio). Typical range: 2.5-4.5.
    
    Raises:
        ValueError: If electrical_input_kwh is zero or negative
        ValueError: If heating_output_kwh is negative
    
    Example:
        >>> scop = calculate_seasonal_cop(
        ...     heating_output_kwh=10000,
        ...     electrical_input_kwh=2500,
        ...     outdoor_temp_avg=5.0
        ... )
        >>> print(f"SCOP: {scop:.2f}")
        SCOP: 4.00
    
    Note:
        This calculation assumes standard test conditions per EN 14825.
        For detailed methodology, see: https://example.com/scop-calculation
    """
    if electrical_input_kwh <= 0:
        raise ValueError(
            f"Electrical input must be positive, got {electrical_input_kwh}"
        )
    if heating_output_kwh < 0:
        raise ValueError(
            f"Heating output cannot be negative, got {heating_output_kwh}"
        )
    
    return heating_output_kwh / electrical_input_kwh
```

### 5.1 Docstring Sections

**Summary line (required):**
- One line, imperative mood ("Calculate X", "Return Y", "Process Z")
- Max 80 characters
- No period at the end

**Description (optional but recommended):**
- Longer explanation of what the function does
- Context, purpose, or algorithm overview
- When to use this function

**Args (required if parameters exist):**
- One line per parameter
- Format: `param_name: Description of parameter`
- Include units, range, or format if relevant
- Don't repeat type information (it's in the signature)

**Returns (required if function returns):**
- Description of return value
- Include type, range, or format if not obvious
- For multiple returns, use format: `tuple: (description_of_first, description_of_second)`

**Raises (required if function can raise):**
- One line per exception type
- Format: `ExceptionType: When and why this is raised`
- Document both direct raises and propagated exceptions

**Example (recommended for public APIs):**
- Executable example showing usage
- Use doctest format (`>>>` prompt)
- Keep examples short and focused

**Note/Warning (optional):**
- Important caveats or limitations
- Performance considerations
- Thread safety information
- Links to external documentation

---

## 6. Examples of Required Docstring Content

### 6.1 Simple Function

**✅ CORRECT:**
```python
def normalize_email(email: str) -> str:
    """Normalize email address to lowercase and trim whitespace.
    
    Args:
        email: Email address to normalize
    
    Returns:
        Normalized email address
    
    Example:
        >>> normalize_email("  Alice@Example.COM  ")
        'alice@example.com'
    """
    return email.strip().lower()
```

### 6.2 Function with Exceptions

**✅ CORRECT:**
```python
def divide(a: float, b: float) -> float:
    """Divide two numbers.
    
    Args:
        a: Numerator
        b: Denominator
    
    Returns:
        Result of a / b
    
    Raises:
        ValueError: If b is zero
    """
    if b == 0:
        raise ValueError("Cannot divide by zero")
    return a / b
```

### 6.3 Function with Complex Return

**✅ CORRECT:**
```python
def parse_config_file(path: Path) -> dict[str, Any]:
    """Parse TOML configuration file.
    
    Args:
        path: Path to TOML configuration file
    
    Returns:
        Dictionary containing configuration with structure:
        {
            'database': {'host': str, 'port': int},
            'logging': {'level': str, 'file': str},
            'features': {'enabled': list[str]}
        }
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        ConfigurationError: If TOML is invalid or required keys missing
    """
    ...
```

### 6.4 Generator Function

**✅ CORRECT:**
```python
def read_large_file_in_chunks(path: Path, chunk_size: int = 8192) -> Iterator[str]:
    """Read file in chunks to avoid loading entire file into memory.
    
    Args:
        path: Path to file to read
        chunk_size: Number of bytes per chunk (default: 8192)
    
    Yields:
        Chunks of file content as strings
    
    Raises:
        FileNotFoundError: If file doesn't exist
        PermissionError: If file isn't readable
    """
    with open(path, 'r') as f:
        while chunk := f.read(chunk_size):
            yield chunk
```

### 6.5 Context Manager

**✅ CORRECT:**
```python
@contextmanager
def temporary_directory() -> Iterator[Path]:
    """Create temporary directory that is cleaned up on exit.
    
    Yields:
        Path to temporary directory
    
    Example:
        >>> with temporary_directory() as temp_dir:
        ...     (temp_dir / "file.txt").write_text("data")
        ...     # Directory deleted after exiting context
    """
    temp_dir = Path(tempfile.mkdtemp())
    try:
        yield temp_dir
    finally:
        shutil.rmtree(temp_dir)
```

---

## 7. Comments vs Docstrings

### 7.1 Use Docstrings For: API Documentation

**✅ CORRECT:**
```python
def process_payment(order: Order, payment_method: PaymentMethod) -> Transaction:
    """Process payment for an order using the specified payment method.
    
    This function validates the payment method, calculates the charge
    amount including tax, and creates a transaction record.
    
    Args:
        order: Order to process payment for
        payment_method: Payment method (credit card, PayPal, etc.)
    
    Returns:
        Transaction record with status and transaction ID
    
    Raises:
        PaymentError: If payment processing fails
        ValidationError: If order or payment method is invalid
    """
    # Implementation...
```

### 7.2 Use Comments For: Implementation Details

**✅ CORRECT:**
```python
def calculate_shipping_cost(order: Order) -> Decimal:
    """Calculate shipping cost for an order.
    
    Args:
        order: Order to calculate shipping for
    
    Returns:
        Shipping cost in USD
    """
    # Free shipping for orders over $50
    if order.total >= Decimal("50.00"):
        return Decimal("0.00")
    
    # Weight-based pricing: $0.50 per pound
    # Note: Using ceiling to always round up (carrier requirement)
    weight_pounds = math.ceil(order.total_weight_kg * 2.20462)
    
    return Decimal(str(weight_pounds * 0.50))
```

### 7.3 Comment Guidelines

**Comments should explain WHY, not WHAT:**

**❌ WRONG - Redundant:**
```python
# Increment counter by 1
counter += 1

# Loop through users
for user in users:
    # Check if user is active
    if user.is_active:
        # Process the user
        process(user)
```

**✅ CORRECT - Explains why:**
```python
# Increment counter to track cache hits
counter += 1

# Only process active users to avoid sending emails to deactivated accounts
for user in users:
    if user.is_active:
        process(user)
```

**Comments are needed for:**
- Non-obvious algorithms or business logic
- Workarounds for bugs in external libraries
- Performance optimizations
- Security considerations
- Compliance or regulatory requirements
- TODOs (but these should be temporary)

---

## 8. Forbidden Patterns

### 8.1 No Commented-Out Code

**❌ FORBIDDEN:**
```python
def process_data(data):
    result = transform(data)
    # old_result = legacy_transform(data)
    # return old_result
    return result
```

**✅ CORRECT - Use version control:**
```python
def process_data(data):
    result = transform(data)
    return result
```

If you need to reference old approaches, use commit history or document in a comment why the current approach was chosen.

### 8.2 No Placeholder Docstrings

**❌ FORBIDDEN:**
```python
def calculate_total(items):
    """TODO: Add docstring."""
    ...

def process(data):
    """This function processes data."""  # Says nothing useful
    ...
```

**✅ CORRECT:**
```python
def calculate_total(items: list[Item]) -> Decimal:
    """Calculate total price including tax and discounts.
    
    Args:
        items: List of items in shopping cart
    
    Returns:
        Total price in USD
    """
    ...
```

### 8.3 No Outdated Documentation

**❌ FORBIDDEN - Docstring doesn't match signature:**
```python
def create_user(email: str, password: str, role: str) -> User:
    """Create a new user account.
    
    Args:
        email: User email address
        password: User password
        # Missing: role parameter
    
    Returns:
        User object
    """
    ...
```

**Prevention:** Use automated tools to detect parameter mismatches.

---

## 9. Documentation Testing

### 9.1 Doctest

Use doctest to ensure examples stay valid:

**✅ CORRECT:**
```python
def celsius_to_fahrenheit(celsius: float) -> float:
    """Convert Celsius to Fahrenheit.
    
    Args:
        celsius: Temperature in Celsius
    
    Returns:
        Temperature in Fahrenheit
    
    Example:
        >>> celsius_to_fahrenheit(0)
        32.0
        >>> celsius_to_fahrenheit(100)
        212.0
        >>> celsius_to_fahrenheit(-40)
        -40.0
    """
    return celsius * 9/5 + 32
```

Run doctests:
```bash
uv run python -m doctest module.py
```

### 9.2 Documentation Coverage

Enforce documentation coverage in CI:

```bash
# Using interrogate
uv run interrogate src/ --fail-under 95

# Or pydocstyle
uv run pydocstyle src/
```

---

## 10. Special Documentation Cases

### 10.1 Deprecated Functions

**✅ CORRECT:**
```python
def legacy_process(data):
    """Process data using legacy algorithm.
    
    .. deprecated:: 2.0
        Use :func:`process_data` instead. This function will be
        removed in version 3.0.
    
    Args:
        data: Input data
    
    Returns:
        Processed data
    """
    warnings.warn(
        "legacy_process is deprecated, use process_data instead",
        DeprecationWarning,
        stacklevel=2
    )
    ...
```

### 10.2 Type Aliases

**✅ CORRECT:**
```python
"""Type definitions for user management."""

from typing import TypeAlias

#: User identifier type. Must be positive integer.
UserId: TypeAlias = int

#: Mapping from user ID to user object
UserRegistry: TypeAlias = dict[UserId, User]
```

### 10.3 Constants

**✅ CORRECT:**
```python
#: Maximum number of retry attempts for failed operations
MAX_RETRIES: int = 3

#: Default timeout in seconds for API requests
DEFAULT_TIMEOUT: float = 30.0

#: Valid HTTP status codes that indicate success
SUCCESS_STATUS_CODES: frozenset[int] = frozenset({200, 201, 204})
```

---

## 11. README and Project Documentation

### 11.1 Required README Sections

Every project MUST have a README.md with:

1. **Project Name and Description** - What does it do?
2. **Installation** - How to install dependencies
3. **Usage** - Basic usage examples
4. **Development** - How to set up dev environment
5. **Testing** - How to run tests
6. **Contributing** (if applicable)
7. **License**

**Minimal README template:**
```markdown
# Project Name

One-paragraph description of what this project does.

## Installation

```bash
git clone https://github.com/user/project.git
cd project
uv sync
```

## Usage

```python
from project import main_function

result = main_function("example")
```

## Development

```bash
# Install dev dependencies
uv sync --group dev

# Run tests
uv run pytest

# Run type checking
uv run mypy src/
```

## License

MIT License - see LICENSE file
```

### 11.2 Architecture Documentation

For complex projects, add `docs/ARCHITECTURE.md`:

```markdown
# Architecture

## Overview

High-level architecture diagram and description.

## Components

### Component 1
Purpose, responsibilities, dependencies.

### Component 2
...

## Data Flow

How data moves through the system.

## Design Decisions

Key decisions and rationale.
```

---

## 12. Enforcement

### 12.1 Automated Checks

**pydocstyle configuration:**
```toml
[tool.pydocstyle]
convention = "google"
add-ignore = ["D100"]  # Optionally ignore module docstrings in tests
```

**interrogate configuration:**
```toml
[tool.interrogate]
ignore-init-method = true
ignore-init-module = false
ignore-magic = true
ignore-module = false
ignore-private = true
fail-under = 95
exclude = ["tests", "build", "dist"]
```

**Ruff:**
```toml
[tool.ruff]
select = ["D"]  # pydocstyle

[tool.ruff.pydocstyle]
convention = "google"
```

### 12.2 CI Integration

```yaml
- name: Check documentation coverage
  run: |
    uv run interrogate src/ --fail-under 95
    uv run pydocstyle src/
```

### 12.3 Code Review Checklist

During code review:
- ✅ All public APIs have docstrings
- ✅ Docstrings match function signatures
- ✅ Examples are provided for complex functions
- ✅ Exceptions are documented
- ✅ Comments explain WHY, not WHAT
- ✅ No commented-out code

---

## 13. Related Rules

- **Type Checking:** Docstrings + types = complete contract
- **Naming Conventions:** Good names reduce documentation burden
- **Clean Table Principle:** Outdated docs are impurities
- **TDD Governance:** Tests verify; docs describe

---

## 14. Summary

**Documentation Requirements:**
- All public modules, classes, functions have docstrings
- Google-style format for consistency
- Document parameters, returns, exceptions
- Include examples for public APIs
- Keep documentation synchronized with code

**Comments vs Docstrings:**
- Docstrings: API documentation (what and how to use)
- Comments: Implementation details (why it works this way)

**Enforcement:**
- Automated coverage checks (interrogate, pydocstyle)
- CI failures on missing or incorrect docstrings
- Code review verification

Good documentation is not an afterthought—it's part of the code contract. If you can't document it clearly, you probably can't implement it correctly.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
