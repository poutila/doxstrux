# Code Quality Rule: CQ-002 - Code Complexity Limits

This project enforces objective complexity limits to prevent functions and classes from becoming unmaintainable. Simple code is easier to test, debug, and modify.

> **Hard rule:**  
> - Functions exceeding complexity limits MUST be refactored.  
> - Complexity violations block code review and CI.  
> - No "temporary" exceptions—refactor or split the code.

---

## Classification

- **Category:** Code Quality / Maintainability
- **Severity:** ERROR
- **Scope:** All production code (exceptions for tests noted below)
- **Enforceability:** Automated (static analysis via ruff/pylint/radon)

---

## 1. Complexity Metrics and Limits

### 1.1 Cyclomatic Complexity (McCabe)

**Limit: 10 per function**

Cyclomatic complexity counts independent code paths (branches, loops).

**What it measures:**
- Each `if`, `elif`, `for`, `while`, `except` adds 1
- Boolean operators (`and`, `or`) add 1
- List comprehensions with conditionals add 1

**Why 10:**
- Research shows complexity >10 correlates with higher bug rates
- Functions >10 are difficult to test exhaustively
- >10 usually indicates missing abstractions

**Example violation:**
```python
# ❌ Complexity: 12 (too high)
def process_order(order, user, inventory):
    if not user.is_authenticated:
        if user.is_guest:
            if order.total < 100:
                return process_guest_order(order)
            else:
                return require_registration()
        else:
            return redirect_to_login()
    
    if order.items:
        for item in order.items:
            if item.id not in inventory:
                if item.is_backorderable:
                    add_to_backorder(item)
                else:
                    return out_of_stock_error(item)
            elif inventory[item.id] < item.quantity:
                return insufficient_stock_error(item)
    
    return complete_order(order)
```

**Compliant refactor:**
```python
# ✅ Complexity: 3 (main), 2 (helper1), 2 (helper2)
def process_order(order, user, inventory):
    _validate_user_authentication(user)
    _validate_inventory_availability(order, inventory)
    return complete_order(order)

def _validate_user_authentication(user):
    if not user.is_authenticated:
        if user.is_guest and order.total < 100:
            return process_guest_order(order)
        return require_authentication()

def _validate_inventory_availability(order, inventory):
    for item in order.items:
        if item.id not in inventory:
            _handle_missing_inventory(item)
        elif inventory[item.id] < item.quantity:
            raise InsufficientStockError(item)
```

### 1.2 Function Length

**Limit: 50 lines of code per function**

Lines of code (LOC) excluding:
- Blank lines
- Comments
- Docstrings

**Why 50:**
- Fits on one screen without scrolling
- Forces decomposition into logical units
- Easier to understand and test

**Example violation:**
```python
# ❌ 80 lines - too long
def generate_report(data):
    # ... 80 lines of processing, formatting, validation ...
    return report
```

**Compliant refactor:**
```python
# ✅ Decomposed into focused functions
def generate_report(data: DataFrame) -> Report:
    validated_data = _validate_report_data(data)
    summary = _calculate_summary_statistics(validated_data)
    formatted = _format_report_sections(summary)
    return Report(data=formatted, generated_at=datetime.now())

def _validate_report_data(data: DataFrame) -> DataFrame:
    # 15 lines of validation
    ...

def _calculate_summary_statistics(data: DataFrame) -> dict:
    # 20 lines of calculations
    ...

def _format_report_sections(summary: dict) -> dict:
    # 15 lines of formatting
    ...
```

### 1.3 Nesting Depth

**Limit: 4 levels of nesting**

**What counts as nesting:**
- `if`/`elif`/`else` blocks
- `for`/`while` loops
- `with` statements
- `try`/`except` blocks
- Function definitions (nested functions)

**Example violation:**
```python
# ❌ Nesting depth: 5 (too deep)
def process_data(items):
    for item in items:  # Level 1
        if item.is_valid:  # Level 2
            try:  # Level 3
                with open(item.path) as f:  # Level 4
                    if f.readable():  # Level 5
                        data = f.read()
                        process(data)
            except IOError:
                log_error(item)
```

**Compliant refactor:**
```python
# ✅ Nesting depth: 2 (max)
def process_data(items):
    for item in items:  # Level 1
        _process_single_item(item)

def _process_single_item(item):
    if not item.is_valid:
        return
    
    try:
        data = _read_item_file(item)  # Level 1
        process(data)
    except IOError:
        log_error(item)

def _read_item_file(item):
    with open(item.path) as f:  # Level 1
        if not f.readable():  # Level 2
            raise IOError(f"Cannot read {item.path}")
        return f.read()
```

### 1.4 Function Parameters

**Limit: 5 parameters per function**

**Why 5:**
- More parameters → harder to understand and test
- Often indicates missing abstraction (e.g., parameter object)
- Reduces cognitive load

**Example violation:**
```python
# ❌ 7 parameters - too many
def create_user(
    username: str,
    email: str,
    password: str,
    first_name: str,
    last_name: str,
    age: int,
    country: str
) -> User:
    ...
```

**Compliant patterns:**

**Option 1: Parameter Object**
```python
# ✅ Using dataclass to group related parameters
@dataclass
class UserProfile:
    username: str
    email: str
    first_name: str
    last_name: str
    age: int
    country: str

def create_user(profile: UserProfile, password: str) -> User:
    ...
```

**Option 2: Builder Pattern**
```python
# ✅ For complex construction
class UserBuilder:
    def __init__(self, username: str, email: str):
        self.username = username
        self.email = email
    
    def with_name(self, first: str, last: str) -> "UserBuilder":
        self.first_name = first
        self.last_name = last
        return self
    
    def with_location(self, age: int, country: str) -> "UserBuilder":
        self.age = age
        self.country = country
        return self
    
    def build(self) -> User:
        return User(...)

# Usage:
user = UserBuilder("alice", "alice@example.com")
    .with_name("Alice", "Smith")
    .with_location(30, "US")
    .build()
```

### 1.5 Class Size

**Limits:**
- **Methods:** Maximum 20 public methods per class
- **Lines:** Maximum 300 lines per class (excluding docstrings)
- **Attributes:** Maximum 10 instance attributes

**Why these limits:**
- Large classes violate Single Responsibility Principle
- Difficult to test and maintain
- Often indicate missing decomposition

**Example violation:**
```python
# ❌ 25 methods, 15 attributes - too large
class OrderProcessor:
    def __init__(self):
        # ... 15 attributes ...
        pass
    
    # ... 25 methods handling validation, inventory, payment, 
    # shipping, notifications, logging, reporting, etc. ...
```

**Compliant refactor:**
```python
# ✅ Split by responsibility
class OrderProcessor:
    """Coordinates order processing workflow."""
    
    def __init__(
        self,
        validator: OrderValidator,
        inventory: InventoryManager,
        payment: PaymentProcessor,
        shipping: ShippingService,
        notifier: NotificationService
    ):
        self.validator = validator
        self.inventory = inventory
        self.payment = payment
        self.shipping = shipping
        self.notifier = notifier
    
    def process(self, order: Order) -> ProcessedOrder:
        self.validator.validate(order)
        self.inventory.reserve(order.items)
        self.payment.charge(order)
        self.shipping.schedule(order)
        self.notifier.send_confirmation(order)
        return ProcessedOrder(order)

# Each of these classes focuses on one responsibility
class OrderValidator: ...
class InventoryManager: ...
class PaymentProcessor: ...
class ShippingService: ...
class NotificationService: ...
```

---

## 2. Enforcement

### 2.1 Automated Tools

**Ruff (recommended):**
```toml
# pyproject.toml
[tool.ruff]
select = ["C90"]  # McCabe complexity

[tool.ruff.mccabe]
max-complexity = 10
```

**Pylint:**
```toml
[tool.pylint.design]
max-complexity = 10
max-args = 5
max-attributes = 10
max-locals = 15
max-branches = 12
max-statements = 50
```

**Radon (standalone):**
```bash
# Check complexity
uv run radon cc src/ -a -nb

# Fail if complexity > 10
uv run radon cc src/ -n B  # B grade = complexity 11-20
```

### 2.2 CI Integration

```yaml
# .github/workflows/quality.yml
- name: Check code complexity
  run: |
    uv run ruff check src/ --select C90
    uv run radon cc src/ -n B  # Fail on grade B or worse
```

### 2.3 Pre-commit Hook (Optional)

```yaml
# .pre-commit-config.yaml
repos:
  - repo: local
    hooks:
      - id: complexity-check
        name: Check cyclomatic complexity
        entry: ruff check --select C90
        language: system
        types: [python]
```

---

## 3. Refactoring Strategies

### 3.1 Extract Method

**Before:**
```python
def process_payment(order, user):
    # Validation (5 lines)
    if not order.items:
        raise ValueError("Empty order")
    if order.total < 0:
        raise ValueError("Negative total")
    if not user.payment_method:
        raise ValueError("No payment method")
    
    # Processing (5 lines)
    charge_amount = order.total + calculate_tax(order)
    transaction = create_transaction(charge_amount)
    result = charge_payment_method(user.payment_method, transaction)
    
    # Confirmation (5 lines)
    if result.success:
        send_receipt(user, transaction)
        update_order_status(order, "paid")
        log_payment(transaction)
    
    return result
```

**After:**
```python
def process_payment(order, user):
    _validate_payment_request(order, user)
    result = _execute_payment(order, user)
    _finalize_payment(result, order, user)
    return result

def _validate_payment_request(order, user):
    if not order.items:
        raise ValueError("Empty order")
    if order.total < 0:
        raise ValueError("Negative total")
    if not user.payment_method:
        raise ValueError("No payment method")

def _execute_payment(order, user):
    charge_amount = order.total + calculate_tax(order)
    transaction = create_transaction(charge_amount)
    return charge_payment_method(user.payment_method, transaction)

def _finalize_payment(result, order, user):
    if result.success:
        send_receipt(user, transaction)
        update_order_status(order, "paid")
        log_payment(transaction)
```

### 3.2 Replace Conditional with Polymorphism

**Before:**
```python
def calculate_shipping(order):
    if order.shipping_method == "standard":
        base = 5.0
        if order.total > 50:
            base = 0
        return base + order.weight * 0.5
    elif order.shipping_method == "express":
        base = 15.0
        if order.total > 100:
            base = 10.0
        return base + order.weight * 1.0
    elif order.shipping_method == "overnight":
        return 30.0 + order.weight * 2.0
    else:
        raise ValueError("Unknown shipping method")
```

**After:**
```python
class ShippingMethod(ABC):
    @abstractmethod
    def calculate_cost(self, order) -> float:
        pass

class StandardShipping(ShippingMethod):
    def calculate_cost(self, order) -> float:
        base = 5.0 if order.total <= 50 else 0
        return base + order.weight * 0.5

class ExpressShipping(ShippingMethod):
    def calculate_cost(self, order) -> float:
        base = 15.0 if order.total <= 100 else 10.0
        return base + order.weight * 1.0

class OvernightShipping(ShippingMethod):
    def calculate_cost(self, order) -> float:
        return 30.0 + order.weight * 2.0

SHIPPING_METHODS = {
    "standard": StandardShipping(),
    "express": ExpressShipping(),
    "overnight": OvernightShipping(),
}

def calculate_shipping(order):
    method = SHIPPING_METHODS.get(order.shipping_method)
    if not method:
        raise ValueError(f"Unknown shipping method: {order.shipping_method}")
    return method.calculate_cost(order)
```

### 3.3 Replace Nested Conditionals with Guard Clauses

**Before:**
```python
def process_item(item):
    if item is not None:
        if item.is_active:
            if item.quantity > 0:
                if item.price > 0:
                    return calculate_total(item)
                else:
                    return 0
            else:
                return 0
        else:
            return 0
    else:
        raise ValueError("Item is None")
```

**After:**
```python
def process_item(item):
    if item is None:
        raise ValueError("Item is None")
    
    if not item.is_active:
        return 0
    
    if item.quantity <= 0:
        return 0
    
    if item.price <= 0:
        return 0
    
    return calculate_total(item)
```

---

## 4. Exceptions

### 4.1 Test Code

Test functions may exceed limits when:
- Testing complex integration scenarios
- Setting up elaborate fixtures
- Testing many similar cases

**Still recommended:** Even in tests, prefer helper functions for setup/teardown.

### 4.2 Generated Code

Generated code (e.g., from protobuf, OpenAPI) may exceed limits. Options:
- Exclude from complexity checks via config
- Wrap in simpler interface layer
- Document as exception in code review

### 4.3 Algorithm Implementation

Complex algorithms (sorting, graph traversal, parsing) may need >10 complexity:
- Document the algorithm with references
- Add extensive comments explaining branches
- Ensure comprehensive test coverage
- Consider as technical debt for future refactoring

---

## 5. Measuring and Reporting

### 5.1 Project-wide Complexity Report

Generate regular complexity reports:

```bash
# Generate complexity report
uv run radon cc src/ -a -s -j > complexity_report.json

# Find worst offenders
uv run radon cc src/ -s | sort -k2 -n | tail -20
```

### 5.2 Trend Analysis

Track complexity over time:
- Run complexity checks in CI
- Store results as artifacts
- Graph trends to catch degradation

### 5.3 Code Review Guidelines

During code review, check:
- ✅ New functions stay under limits
- ✅ Changes don't increase complexity of existing functions
- ✅ Refactoring reduces complexity when possible

---

## 6. Related Rules

- **TDD Governance:** Complex functions are harder to test
- **No Weak Tests:** Complex functions need more test coverage
- **Clean Table Principle:** Complexity is technical debt
- **Error Handling:** Nested error handling increases complexity

---

## 7. Summary

**Hard Limits:**
- Cyclomatic complexity: ≤10 per function
- Function length: ≤50 lines of code
- Nesting depth: ≤4 levels
- Function parameters: ≤5 parameters
- Class methods: ≤20 public methods
- Class attributes: ≤10 instance attributes

**Enforcement:**
- Automated checks via ruff/pylint/radon
- CI fails on violations
- Code review verification

**Refactoring Patterns:**
- Extract method
- Replace conditional with polymorphism
- Guard clauses for early returns
- Parameter objects for many parameters
- Split large classes by responsibility

Complexity limits are not arbitrary—they're based on research showing that simpler code has fewer bugs, is easier to modify, and is cheaper to maintain.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
