# Error Handling Governance — Fail Fast, Fail Clearly (Project Rule)

This project enforces systematic error handling to ensure failures are detected early, reported clearly, and handled consistently throughout the codebase.

> **Hard rule:**  
> - All errors must fail loudly with clear context about what failed and why.  
> - Exception messages must include actionable information for debugging.  
> - Never swallow exceptions without explicit justification and logging.  
> - Use custom exception types to distinguish between error categories.

---

## Classification

- **Category:** Error Handling / Reliability
- **Severity:** ERROR
- **Scope:** All code that can fail
- **Enforceability:** Code review + runtime monitoring

---

## 1. Goals

- **Early Detection:** Catch errors at their source, not downstream where context is lost
- **Clear Diagnosis:** Error messages must enable rapid debugging without additional investigation
- **Predictable Behavior:** Same error conditions always produce the same exceptions
- **Recovery Clarity:** Make it obvious whether an error is recoverable or fatal

This rule complements:
- **Clean Table Principle:** No silent errors that leave the system in an undefined state
- **TDD Governance:** Tests must verify error conditions, not just happy paths
- **Type Checking:** Static types catch some errors; runtime handling catches the rest

---

## 2. Exception Hierarchy

### 2.1 Required Custom Exceptions

Create custom exceptions for domain-specific failures:

```python
# ✅ CORRECT - Clear exception hierarchy
class ProjectError(Exception):
    """Base exception for all project-specific errors."""
    pass

class ValidationError(ProjectError):
    """Data validation failed."""
    pass

class ResourceNotFoundError(ProjectError):
    """Required resource could not be located."""
    pass

class ConfigurationError(ProjectError):
    """Invalid configuration detected."""
    pass

class DataCorruptionError(ProjectError):
    """Data integrity violation detected."""
    pass
```

### 2.2 When to Create Custom Exceptions

Create a custom exception when:
- The error represents a distinct failure mode in your domain
- Callers might want to catch and handle this specific error
- You need to attach structured context (error codes, metadata)

**Example:**
```python
class FactKeyNotFoundError(ProjectError):
    """Fact key not found in FACTS.parquet."""
    
    def __init__(self, key: str, available_keys: list[str]):
        self.key = key
        self.available_keys = available_keys
        super().__init__(
            f"Fact key '{key}' not found. "
            f"Available keys: {', '.join(available_keys[:5])}..."
        )
```

---

## 3. Error Context Requirements

### 3.1 Required Information in Error Messages

Every error message MUST include:
1. **What failed** (operation/function name)
2. **Why it failed** (root cause)
3. **Context** (relevant inputs, state, or identifiers)

**❌ BAD:**
```python
raise ValueError("Invalid input")
raise RuntimeError("Failed")
raise Exception("Error in processing")
```

**✅ GOOD:**
```python
raise ValidationError(
    f"Invalid email format: '{email}'. Expected format: user@domain.com"
)

raise ResourceNotFoundError(
    f"FACTS.parquet not found at {facts_path}. "
    f"Run 'uv run python -m package.fact_file_generator' to create it."
)

raise DataCorruptionError(
    f"Temperature reading {temp}°C outside valid range [-50, 100]. "
    f"Sensor: {sensor_id}, Timestamp: {timestamp}"
)
```

### 3.2 Actionable Error Messages

Error messages should tell users **what to do**:

**✅ GOOD:**
```python
raise ConfigurationError(
    f"Missing required config key: 'api_key'. "
    f"Add 'api_key = \"your-key\"' to config.toml or set API_KEY environment variable."
)

raise StaleFactsError(
    f"FACTS.parquet is stale (last updated: {last_updated}). "
    f"Regenerate with: uv run python -m package.fact_file_generator"
)
```

---

## 4. Exception Handling Patterns

### 4.1 Fail Fast (Preferred)

Let exceptions propagate to the caller unless you can meaningfully recover:

**✅ CORRECT:**
```python
def load_config(path: Path) -> Config:
    """Load configuration from file.
    
    Raises:
        ConfigurationError: If file is missing or invalid
    """
    if not path.exists():
        raise ConfigurationError(
            f"Config file not found: {path}. "
            f"Create it with: cp config.example.toml {path}"
        )
    
    try:
        return toml.loads(path.read_text())
    except toml.TomlDecodeError as e:
        raise ConfigurationError(
            f"Invalid TOML in {path}: {e}"
        ) from e
```

### 4.2 Recovery (When Appropriate)

Only catch exceptions when you can **meaningfully recover**:

**✅ CORRECT - Has fallback:**
```python
def get_cache_dir() -> Path:
    """Get cache directory, creating it if needed."""
    try:
        cache_dir = Path.home() / ".cache" / "myproject"
        cache_dir.mkdir(parents=True, exist_ok=True)
        return cache_dir
    except PermissionError:
        # Fallback to temp directory
        temp_cache = Path(tempfile.gettempdir()) / "myproject"
        temp_cache.mkdir(parents=True, exist_ok=True)
        logger.warning(f"Using temporary cache directory: {temp_cache}")
        return temp_cache
```

**❌ WRONG - No meaningful recovery:**
```python
def load_critical_data(path: Path) -> DataFrame:
    try:
        return pl.read_parquet(path)
    except Exception as e:
        logger.error(f"Failed to load {path}: {e}")
        return pl.DataFrame()  # Returns empty data - silent corruption!
```

### 4.3 Exception Chaining

Always use `raise ... from ...` to preserve the exception chain:

**✅ CORRECT:**
```python
try:
    data = json.loads(response.text)
except json.JSONDecodeError as e:
    raise DataCorruptionError(
        f"Invalid JSON response from API: {e}"
    ) from e
```

**❌ WRONG - Loses original traceback:**
```python
try:
    data = json.loads(response.text)
except json.JSONDecodeError as e:
    raise DataCorruptionError(f"Invalid JSON response from API: {e}")
```

---

## 5. Forbidden Patterns

### 5.1 Silent Failure

**❌ FORBIDDEN:**
```python
try:
    result = risky_operation()
except Exception:
    pass  # Silent failure!

try:
    result = risky_operation()
except Exception as e:
    print(f"Warning: {e}")  # Not loud enough!
    result = None
```

**✅ CORRECT:**
```python
try:
    result = risky_operation()
except ExpectedError as e:
    logger.exception("Operation failed")
    raise  # Re-raise to propagate
```

### 5.2 Bare `except:`

**❌ FORBIDDEN:**
```python
try:
    operation()
except:  # Catches SystemExit, KeyboardInterrupt, etc.!
    handle_error()
```

**✅ CORRECT:**
```python
try:
    operation()
except Exception as e:  # Only catches Exception and subclasses
    handle_error(e)
```

### 5.3 Generic Exception Messages

**❌ FORBIDDEN:**
```python
raise Exception("Something went wrong")
raise RuntimeError("Error")
raise ValueError("Invalid value")
```

### 5.4 Exception as Flow Control

**❌ FORBIDDEN:**
```python
def get_user(user_id: int) -> User:
    try:
        return users[user_id]
    except KeyError:
        # Using exception for normal flow control
        return create_default_user(user_id)
```

**✅ CORRECT:**
```python
def get_user(user_id: int) -> User:
    if user_id in users:
        return users[user_id]
    return create_default_user(user_id)
```

Exception: Using exceptions for flow control is acceptable when:
- Checking is more expensive than try/except (rare in Python)
- Following established patterns (e.g., `StopIteration`)

---

## 6. Logging vs Raising

### 6.1 Choose One: Log or Raise, Not Both

**❌ FORBIDDEN:**
```python
try:
    result = operation()
except ValueError as e:
    logger.error(f"Operation failed: {e}")  # Logged
    raise  # And raised - duplicates the error!
```

**✅ CORRECT - Log and handle:**
```python
try:
    result = operation()
except ValueError as e:
    logger.exception("Operation failed, using fallback")
    return fallback_value()
```

**✅ CORRECT - Just raise:**
```python
try:
    result = operation()
except ValueError as e:
    # Let caller handle it
    raise OperationError(f"Operation failed: {e}") from e
```

### 6.2 Log at Error Boundaries

Log exceptions at **error boundaries** (entry points, API endpoints):

```python
# Entry point - log here
def main():
    try:
        run_application()
    except Exception as e:
        logger.exception("Application crashed")
        sys.exit(1)

# Internal function - just raise
def run_application():
    config = load_config()  # May raise ConfigurationError
    process_data(config)    # May raise DataError
```

---

## 7. Error Recovery Strategies

### 7.1 Retry with Backoff

For transient failures:

```python
import time
from typing import TypeVar, Callable

T = TypeVar('T')

def retry_with_backoff(
    func: Callable[[], T],
    max_attempts: int = 3,
    backoff_factor: float = 2.0
) -> T:
    """Retry function with exponential backoff.
    
    Raises:
        The last exception if all retries fail
    """
    for attempt in range(max_attempts):
        try:
            return func()
        except (ConnectionError, TimeoutError) as e:
            if attempt == max_attempts - 1:
                raise
            wait_time = backoff_factor ** attempt
            logger.warning(f"Attempt {attempt + 1} failed: {e}. Retrying in {wait_time}s...")
            time.sleep(wait_time)
    
    raise RuntimeError("Should not reach here")
```

### 7.2 Circuit Breaker

For protecting against cascading failures:

```python
class CircuitBreaker:
    """Prevent repeated calls to failing operations."""
    
    def __init__(self, failure_threshold: int = 5, timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.timeout = timeout
        self.failures = 0
        self.last_failure_time: float | None = None
        self.state = "closed"  # closed, open, half-open
    
    def call(self, func: Callable[[], T]) -> T:
        if self.state == "open":
            if time.time() - self.last_failure_time > self.timeout:
                self.state = "half-open"
            else:
                raise CircuitBreakerError("Circuit breaker is open")
        
        try:
            result = func()
            self.on_success()
            return result
        except Exception as e:
            self.on_failure()
            raise
    
    def on_success(self):
        self.failures = 0
        self.state = "closed"
    
    def on_failure(self):
        self.failures += 1
        self.last_failure_time = time.time()
        if self.failures >= self.failure_threshold:
            self.state = "open"
```

---

## 8. Testing Error Conditions

### 8.1 Test All Error Paths

Every error condition MUST have a test:

```python
def test_load_config_missing_file():
    """Test that missing config file raises clear error."""
    with pytest.raises(ConfigurationError) as exc_info:
        load_config(Path("nonexistent.toml"))
    
    assert "not found" in str(exc_info.value).lower()
    assert "nonexistent.toml" in str(exc_info.value)

def test_validate_temperature_out_of_range():
    """Test that invalid temperature raises with context."""
    with pytest.raises(ValidationError) as exc_info:
        validate_temperature(150.0)
    
    error_msg = str(exc_info.value)
    assert "150.0" in error_msg
    assert "range" in error_msg.lower()
```

### 8.2 Test Error Messages

Verify error messages contain required context:

```python
def test_fact_key_not_found_error_includes_available_keys():
    """Test that FactKeyNotFoundError suggests available keys."""
    available = ["key1", "key2", "key3"]
    error = FactKeyNotFoundError("invalid_key", available)
    
    error_msg = str(error)
    assert "invalid_key" in error_msg
    assert "key1" in error_msg or "Available keys" in error_msg
```

---

## 9. Documentation Requirements

### 9.1 Document Exceptions in Docstrings

All functions that can raise exceptions MUST document them:

```python
def load_facts(path: Path) -> pl.DataFrame:
    """Load facts from parquet file.
    
    Args:
        path: Path to FACTS.parquet file
    
    Returns:
        DataFrame containing fact data
    
    Raises:
        ResourceNotFoundError: If facts file doesn't exist
        DataCorruptionError: If parquet file is corrupted
        ValidationError: If required columns are missing
    """
    if not path.exists():
        raise ResourceNotFoundError(f"Facts file not found: {path}")
    
    try:
        df = pl.read_parquet(path)
    except Exception as e:
        raise DataCorruptionError(f"Failed to read {path}: {e}") from e
    
    required_columns = {"key", "value", "type"}
    if not required_columns.issubset(df.columns):
        missing = required_columns - set(df.columns)
        raise ValidationError(f"Missing required columns: {missing}")
    
    return df
```

---

## 10. Error Codes (Optional)

For systems with many error types, consider error codes:

```python
class ProjectError(Exception):
    """Base exception with error code support."""
    
    code: str = "E000"
    
    def __init__(self, message: str):
        super().__init__(f"[{self.code}] {message}")

class StaleFactsError(ProjectError):
    """Facts file is stale."""
    code = "E001"

class FactKeyNotFoundError(ProjectError):
    """Fact key not found."""
    code = "E002"

# Usage:
raise StaleFactsError("FACTS.parquet last updated 2 hours ago")
# Output: [E001] FACTS.parquet last updated 2 hours ago
```

---

## 11. Related Rules

- **Clean Table Principle:** No silent errors
- **TDD Governance:** Test error conditions
- **Type Checking:** Catch errors statically where possible
- **Logging & Observability:** Log errors at boundaries

---

## 12. Summary

- **Fail fast** with clear, actionable error messages
- **Use custom exceptions** to distinguish error categories
- **Include context** in every error: what, why, and how to fix
- **Chain exceptions** with `raise ... from ...`
- **Never swallow exceptions** without explicit recovery logic
- **Document exceptions** in function docstrings
- **Test all error paths** with strong assertions

Error handling is not defensive programming—it's about making failures obvious, diagnosable, and recoverable.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
