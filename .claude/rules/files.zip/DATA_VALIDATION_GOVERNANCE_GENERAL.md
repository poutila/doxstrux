# Data Validation Governance — DV-001 (Project Rule)

This project enforces systematic data validation to prevent invalid data from propagating through the system. Validate data at boundaries; trust internal data only when validation is guaranteed.

> **Hard rule:**  
> - Validate all external inputs at system boundaries.  
> - Use schema validation libraries (Pydantic, Pandera) for complex data.  
> - Fail fast with clear validation errors—no silent coercion or guessing.  
> - Document expected data formats and constraints.

---

## Classification

- **Category:** Data Quality / Reliability
- **Severity:** ERROR
- **Scope:** All code handling external data
- **Enforceability:** Code review + runtime validation

---

## 1. Goals

- **Data Integrity:** Prevent invalid data from entering the system
- **Security:** Protect against injection attacks and malicious input
- **Debugging:** Catch bad data at the source, not after transformation
- **Documentation:** Validation schemas serve as executable data contracts

This rule complements:
- **Error Handling:** Validation failures raise clear exceptions
- **Type Checking:** Runtime validation complements static type checking
- **Clean Table Principle:** Invalid data is an impurity that must be rejected

---

## 2. Validation Boundaries

### 2.1 Where to Validate

**MUST validate at these boundaries:**
- User input (forms, APIs, CLI arguments)
- File parsing (CSV, JSON, Parquet, config files)
- Database queries (results may not match schema)
- External API responses
- Environment variables
- Any untrusted data source

**MAY skip validation:**
- Internal function calls (when inputs are already validated)
- Private methods within a class (caller responsibility)
- Data from trusted, type-safe sources

**Example boundary validation:**
```python
# Boundary: API endpoint
@app.post("/users")
def create_user(request: Request):
    # ✅ Validate at boundary
    user_data = validate_user_input(request.json())
    
    # Internal functions can trust validated data
    user = _create_user_record(user_data)
    _send_welcome_email(user)
    return user

def _create_user_record(user_data: ValidatedUserData):
    # No validation needed - data already validated
    return User(**user_data)
```

---

## 3. Validation Strategies

### 3.1 Use Pydantic for Structured Data

**✅ CORRECT - Pydantic model:**
```python
from pydantic import BaseModel, EmailStr, Field, validator
from datetime import datetime

class UserCreate(BaseModel):
    """Schema for user creation."""
    
    email: EmailStr  # Validates email format
    username: str = Field(min_length=3, max_length=30, pattern="^[a-zA-Z0-9_]+$")
    age: int = Field(ge=18, le=120)  # 18 <= age <= 120
    password: str = Field(min_length=8)
    
    @validator('password')
    def password_strength(cls, v):
        """Ensure password contains letters and numbers."""
        if not any(c.isalpha() for c in v):
            raise ValueError('Password must contain letters')
        if not any(c.isdigit() for c in v):
            raise ValueError('Password must contain numbers')
        return v
    
    class Config:
        # Reject unknown fields
        extra = 'forbid'

# Usage:
try:
    user_data = UserCreate(**request.json())
    # Data is validated and type-safe
except ValidationError as e:
    return {"error": "Invalid input", "details": e.errors()}
```

### 3.2 Use Pandera for DataFrames

For Polars/Pandas DataFrames:

**✅ CORRECT - Pandera schema:**
```python
import pandera as pa
import polars as pl
from pandera.polars import DataFrameModel

class TemperatureReadingSchema(DataFrameModel):
    """Schema for temperature sensor readings."""
    
    timestamp: pl.Datetime = pa.Field(nullable=False)
    sensor_id: str = pa.Field(str_length={'min_value': 1, 'max_value': 50})
    temperature_celsius: float = pa.Field(ge=-50, le=100)  # Valid temp range
    humidity_percent: float = pa.Field(ge=0, le=100, nullable=True)
    
    class Config:
        strict = True  # Reject extra columns
        coerce = False  # Don't coerce types

# Usage:
@pa.check_types
def process_temperature_data(data: pl.DataFrame) -> pl.DataFrame:
    """Process temperature readings.
    
    Args:
        data: Temperature readings matching TemperatureReadingSchema
    
    Returns:
        Processed temperature data
    """
    # Validation happens automatically via decorator
    return data.with_columns(
        temperature_fahrenheit=(pl.col("temperature_celsius") * 9/5) + 32
    )

# Or explicit validation:
try:
    validated_data = TemperatureReadingSchema.validate(raw_data)
except pa.errors.SchemaError as e:
    logger.error("Invalid temperature data: %s", e)
    raise ValidationError(f"Temperature data validation failed: {e}")
```

### 3.3 Manual Validation for Simple Cases

When Pydantic/Pandera is overkill:

**✅ CORRECT - Simple validation:**
```python
def validate_port(port: int) -> int:
    """Validate network port number.
    
    Args:
        port: Port number to validate
    
    Returns:
        Validated port number
    
    Raises:
        ValueError: If port is out of valid range
    """
    if not (1 <= port <= 65535):
        raise ValueError(f"Port must be between 1 and 65535, got {port}")
    return port

def validate_email(email: str) -> str:
    """Validate email address format.
    
    Args:
        email: Email address to validate
    
    Returns:
        Normalized email (lowercase, trimmed)
    
    Raises:
        ValueError: If email format is invalid
    """
    email = email.strip().lower()
    
    if "@" not in email:
        raise ValueError(f"Invalid email: missing '@' in '{email}'")
    
    local, domain = email.split("@", 1)
    
    if not local or not domain:
        raise ValueError(f"Invalid email: empty local or domain part in '{email}'")
    
    if "." not in domain:
        raise ValueError(f"Invalid email: domain must contain '.' in '{email}'")
    
    return email
```

---

## 4. Validation Rules

### 4.1 Fail Fast with Clear Errors

**❌ WRONG - Silent coercion:**
```python
def process_age(age):
    # Silently coerces invalid input
    try:
        return int(age)
    except:
        return 0  # Default - loses information about failure!
```

**✅ CORRECT - Explicit validation:**
```python
def process_age(age: str) -> int:
    """Parse and validate age from string.
    
    Args:
        age: Age as string
    
    Returns:
        Validated age as integer
    
    Raises:
        ValueError: If age is not a valid integer or out of range
    """
    try:
        age_int = int(age)
    except ValueError:
        raise ValueError(f"Age must be an integer, got '{age}'")
    
    if not (0 <= age_int <= 150):
        raise ValueError(f"Age must be between 0 and 150, got {age_int}")
    
    return age_int
```

### 4.2 Validate Constraints, Not Just Types

**❌ INSUFFICIENT - Only type checking:**
```python
def set_temperature(temp: float) -> None:
    # Type is correct but value could be nonsensical
    sensor.temperature = temp
```

**✅ CORRECT - Validates constraints:**
```python
def set_temperature(temp: float) -> None:
    """Set sensor temperature.
    
    Args:
        temp: Temperature in Celsius
    
    Raises:
        ValueError: If temperature is outside valid range
    """
    if not (-273.15 <= temp <= 1000):  # Physical limits
        raise ValueError(
            f"Temperature {temp}°C is outside valid range [-273.15, 1000]"
        )
    sensor.temperature = temp
```

### 4.3 Validate Relationships Between Fields

**✅ CORRECT - Cross-field validation:**
```python
class DateRange(BaseModel):
    """Date range with validation."""
    
    start_date: datetime
    end_date: datetime
    
    @validator('end_date')
    def end_after_start(cls, v, values):
        """Ensure end_date is after start_date."""
        if 'start_date' in values and v < values['start_date']:
            raise ValueError('end_date must be after start_date')
        return v

class Order(BaseModel):
    """Order with line items."""
    
    items: list[LineItem]
    total: Decimal
    
    @validator('total')
    def total_matches_items(cls, v, values):
        """Ensure total matches sum of line items."""
        if 'items' in values:
            calculated_total = sum(item.price * item.quantity for item in values['items'])
            if abs(v - calculated_total) > Decimal('0.01'):
                raise ValueError(
                    f'Total {v} does not match sum of items {calculated_total}'
                )
        return v
```

---

## 5. File Format Validation

### 5.1 CSV Validation

**✅ CORRECT - Validate CSV structure:**
```python
import polars as pl
from typing import Literal

def load_temperature_csv(path: Path) -> pl.DataFrame:
    """Load and validate temperature data from CSV.
    
    Args:
        path: Path to CSV file
    
    Returns:
        Validated temperature data
    
    Raises:
        ValidationError: If CSV structure or data is invalid
    """
    required_columns = {"timestamp", "sensor_id", "temperature_celsius"}
    
    try:
        df = pl.read_csv(path)
    except Exception as e:
        raise ValidationError(f"Failed to parse CSV: {e}")
    
    # Validate columns exist
    missing_columns = required_columns - set(df.columns)
    if missing_columns:
        raise ValidationError(
            f"Missing required columns: {missing_columns}. "
            f"Available: {set(df.columns)}"
        )
    
    # Validate data types and ranges
    try:
        validated = df.with_columns([
            pl.col("timestamp").str.strptime(pl.Datetime, "%Y-%m-%d %H:%M:%S"),
            pl.col("temperature_celsius").cast(pl.Float64)
        ])
    except Exception as e:
        raise ValidationError(f"Invalid data types: {e}")
    
    # Validate temperature range
    invalid_temps = validated.filter(
        (pl.col("temperature_celsius") < -50) | 
        (pl.col("temperature_celsius") > 100)
    )
    
    if len(invalid_temps) > 0:
        raise ValidationError(
            f"Found {len(invalid_temps)} temperature readings outside valid range [-50, 100]"
        )
    
    return validated
```

### 5.2 JSON Validation

**✅ CORRECT - Validate JSON structure:**
```python
import json
from typing import Any

def load_config(path: Path) -> dict[str, Any]:
    """Load and validate configuration from JSON.
    
    Args:
        path: Path to JSON config file
    
    Returns:
        Validated configuration dictionary
    
    Raises:
        ValidationError: If JSON is invalid or missing required keys
    """
    try:
        with open(path) as f:
            config = json.load(f)
    except json.JSONDecodeError as e:
        raise ValidationError(f"Invalid JSON in {path}: {e}")
    except FileNotFoundError:
        raise ValidationError(f"Config file not found: {path}")
    
    # Validate required keys
    required_keys = {"database_url", "api_key", "log_level"}
    missing_keys = required_keys - set(config.keys())
    if missing_keys:
        raise ValidationError(f"Missing required config keys: {missing_keys}")
    
    # Validate specific fields
    if config["log_level"] not in {"DEBUG", "INFO", "WARNING", "ERROR"}:
        raise ValidationError(
            f"Invalid log_level: {config['log_level']}. "
            f"Must be one of: DEBUG, INFO, WARNING, ERROR"
        )
    
    return config
```

### 5.3 Parquet Validation

**✅ CORRECT - Validate Parquet schema:**
```python
def load_facts(path: Path) -> pl.DataFrame:
    """Load and validate FACTS.parquet.
    
    Args:
        path: Path to FACTS.parquet
    
    Returns:
        Validated facts DataFrame
    
    Raises:
        ValidationError: If schema or data is invalid
    """
    try:
        df = pl.read_parquet(path)
    except Exception as e:
        raise ValidationError(f"Failed to read parquet: {e}")
    
    # Validate schema
    expected_schema = {
        "key": pl.Utf8,
        "value": pl.Utf8,
        "type": pl.Utf8,
        "source_file": pl.Utf8,
        "line_number": pl.Int64
    }
    
    for col_name, expected_type in expected_schema.items():
        if col_name not in df.columns:
            raise ValidationError(f"Missing required column: {col_name}")
        
        actual_type = df[col_name].dtype
        if actual_type != expected_type:
            raise ValidationError(
                f"Column '{col_name}' has wrong type: "
                f"expected {expected_type}, got {actual_type}"
            )
    
    # Validate no null keys
    null_keys = df.filter(pl.col("key").is_null())
    if len(null_keys) > 0:
        raise ValidationError(f"Found {len(null_keys)} rows with null keys")
    
    return df
```

---

## 6. API Input Validation

### 6.1 REST API Validation

**✅ CORRECT - FastAPI with Pydantic:**
```python
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI()

class CreateOrderRequest(BaseModel):
    user_id: int = Field(gt=0)
    items: list[str] = Field(min_items=1, max_items=100)
    total: float = Field(gt=0, le=1_000_000)

@app.post("/orders")
async def create_order(order: CreateOrderRequest):
    """Create a new order.
    
    Args:
        order: Order details (validated automatically by Pydantic)
    
    Returns:
        Created order with ID
    """
    # order is guaranteed to be valid by this point
    order_id = save_order(order)
    return {"order_id": order_id, "status": "created"}
```

### 6.2 CLI Argument Validation

**✅ CORRECT - Click with validation:**
```python
import click
from pathlib import Path

@click.command()
@click.argument('input_file', type=click.Path(exists=True, path_type=Path))
@click.option('--port', type=click.IntRange(1, 65535), default=8080)
@click.option('--log-level', type=click.Choice(['DEBUG', 'INFO', 'WARNING', 'ERROR']))
def main(input_file: Path, port: int, log_level: str):
    """Process input file.
    
    Args are validated by Click decorators.
    """
    print(f"Processing {input_file} on port {port} with log level {log_level}")
```

---

## 7. Error Reporting

### 7.1 Provide Actionable Error Messages

**❌ WRONG - Vague error:**
```python
if not valid:
    raise ValueError("Invalid data")
```

**✅ CORRECT - Specific error:**
```python
if temperature < -50 or temperature > 100:
    raise ValueError(
        f"Temperature {temperature}°C is outside valid range [-50, 100]. "
        f"Check sensor calibration or data source."
    )
```

### 7.2 Aggregate Multiple Validation Errors

**✅ CORRECT - Collect all errors:**
```python
def validate_user_data(data: dict) -> dict:
    """Validate user data and collect all errors.
    
    Args:
        data: User data dictionary
    
    Returns:
        Validated data
    
    Raises:
        ValidationError: With all validation failures
    """
    errors = []
    
    if 'email' not in data:
        errors.append("Missing required field: email")
    elif not is_valid_email(data['email']):
        errors.append(f"Invalid email format: {data['email']}")
    
    if 'age' not in data:
        errors.append("Missing required field: age")
    elif not (18 <= data['age'] <= 120):
        errors.append(f"Age must be between 18 and 120, got {data['age']}")
    
    if 'username' not in data:
        errors.append("Missing required field: username")
    elif len(data['username']) < 3:
        errors.append("Username must be at least 3 characters")
    
    if errors:
        raise ValidationError(
            f"Validation failed with {len(errors)} error(s):\n" +
            "\n".join(f"  - {err}" for err in errors)
        )
    
    return data
```

---

## 8. Performance Considerations

### 8.1 Validate Once at Boundaries

**❌ INEFFICIENT - Validates everywhere:**
```python
def process_data(data):
    validate(data)  # Validates
    
    transformed = transform(data)
    validate(transformed)  # Validates again - unnecessary
    
    result = finalize(transformed)
    validate(result)  # Validates again - unnecessary
    
    return result
```

**✅ EFFICIENT - Validate once:**
```python
def process_data(data):
    # Validate at boundary
    validated = validate(data)
    
    # Internal functions trust validated data
    transformed = _transform(validated)
    result = _finalize(transformed)
    
    return result
```

### 8.2 Use Type System to Track Validation

**✅ CORRECT - Type-safe validation:**
```python
from typing import NewType

# Unvalidated data
RawEmail = str

# Validated data
ValidatedEmail = NewType('ValidatedEmail', str)

def validate_email(email: RawEmail) -> ValidatedEmail:
    """Validate email and return validated type."""
    if '@' not in email:
        raise ValueError(f"Invalid email: {email}")
    return ValidatedEmail(email.lower())

def send_email(email: ValidatedEmail) -> None:
    """Send email (requires validated email)."""
    # Type system ensures email is validated
    ...
```

---

## 9. Testing Validation

### 9.1 Test Valid Inputs

**✅ CORRECT:**
```python
def test_validate_temperature_valid():
    """Test validation accepts valid temperature."""
    assert validate_temperature(20.0) == 20.0
    assert validate_temperature(-50.0) == -50.0
    assert validate_temperature(100.0) == 100.0
```

### 9.2 Test Invalid Inputs

**✅ CORRECT:**
```python
def test_validate_temperature_too_low():
    """Test validation rejects temperature below minimum."""
    with pytest.raises(ValueError) as exc_info:
        validate_temperature(-51.0)
    
    assert "-51.0" in str(exc_info.value)
    assert "[-50, 100]" in str(exc_info.value)

def test_validate_temperature_too_high():
    """Test validation rejects temperature above maximum."""
    with pytest.raises(ValueError) as exc_info:
        validate_temperature(101.0)
    
    assert "101.0" in str(exc_info.value)
```

### 9.3 Test Edge Cases

**✅ CORRECT:**
```python
def test_validate_email_edge_cases():
    """Test email validation edge cases."""
    # Valid edge cases
    assert validate_email("a@b.co")
    assert validate_email("user+tag@domain.com")
    
    # Invalid edge cases
    with pytest.raises(ValueError):
        validate_email("")
    
    with pytest.raises(ValueError):
        validate_email("@domain.com")
    
    with pytest.raises(ValueError):
        validate_email("user@")
    
    with pytest.raises(ValueError):
        validate_email("user@domain")  # No TLD
```

---

## 10. Documentation

### 10.1 Document Validation Rules

**✅ CORRECT - Document in docstring:**
```python
def calculate_cop(heating_kwh: float, electrical_kwh: float) -> float:
    """Calculate Coefficient of Performance.
    
    Args:
        heating_kwh: Heating energy output in kWh (must be > 0)
        electrical_kwh: Electrical energy input in kWh (must be > 0)
    
    Returns:
        COP value (heating_kwh / electrical_kwh)
    
    Raises:
        ValueError: If either input is <= 0
    
    Constraints:
        - Both inputs must be positive
        - Result should typically be in range [2, 6] for heat pumps
    """
    if heating_kwh <= 0:
        raise ValueError(f"Heating output must be positive, got {heating_kwh}")
    if electrical_kwh <= 0:
        raise ValueError(f"Electrical input must be positive, got {electrical_kwh}")
    
    return heating_kwh / electrical_kwh
```

### 10.2 Document Data Schemas

**✅ CORRECT - Schema documentation:**
```python
"""Temperature sensor data schema.

Expected format:
- timestamp: ISO 8601 datetime string
- sensor_id: Alphanumeric string, 1-50 characters
- temperature_celsius: Float, valid range [-50, 100]
- humidity_percent: Optional float, valid range [0, 100]

Example:
{
    "timestamp": "2025-12-18T10:30:00Z",
    "sensor_id": "SENSOR_001",
    "temperature_celsius": 22.5,
    "humidity_percent": 65.0
}
"""
```

---

## 11. Related Rules

- **Error Handling:** Validation failures raise clear exceptions
- **Type Checking:** Static types + runtime validation = robust code
- **TDD Governance:** Test both valid and invalid inputs
- **Clean Table Principle:** Invalid data is an impurity

---

## 12. Summary

**Core Principles:**
- Validate at system boundaries
- Fail fast with clear error messages
- Use schema validation libraries (Pydantic, Pandera)
- Document validation rules and constraints

**Validation Strategies:**
- Pydantic for structured data (APIs, configs)
- Pandera for DataFrames
- Manual validation for simple cases
- Type system to track validated vs unvalidated data

**What to Validate:**
- Type correctness
- Range constraints
- Format requirements
- Cross-field relationships
- Business rules

**Testing:**
- Test valid inputs (happy path)
- Test invalid inputs (error cases)
- Test edge cases and boundaries
- Verify error messages are clear

Validation is not defensive programming—it's about making invalid states unrepresentable and catching bad data before it causes damage.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
