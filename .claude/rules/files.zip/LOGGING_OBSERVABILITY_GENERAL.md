# Logging & Observability — OBS-001 (Project Rule)

This project enforces structured, consistent logging to enable debugging, monitoring, and operational visibility. Logs are the runtime documentation of what the system is doing.

> **Hard rule:**  
> - Use Python's `logging` module, not `print()` statements.  
> - Log at appropriate levels (DEBUG/INFO/WARNING/ERROR/CRITICAL).  
> - Never log secrets, passwords, PII, or excessive data.  
> - Use structured logging (key-value pairs) for production systems.

---

## Classification

- **Category:** Observability / Operations
- **Severity:** ERROR
- **Scope:** All production code
- **Enforceability:** Code review + automated checks

---

## 1. Goals

- **Debugging:** Diagnose issues without attaching a debugger
- **Monitoring:** Track system health and performance
- **Auditing:** Record important actions and decisions
- **Operations:** Understand system behavior in production

This rule complements:
- **Error Handling:** Log errors at boundaries; raise for propagation
- **Clean Table Principle:** Useful logs, not noise
- **TDD Governance:** Tests verify behavior; logs reveal runtime state

---

## 2. Logging Basics

### 2.1 Use Python's logging Module

**❌ FORBIDDEN:**
```python
print(f"Processing user {user_id}")  # Not a log!
print(f"Error: {e}")  # Lost in production
```

**✅ CORRECT:**
```python
import logging

logger = logging.getLogger(__name__)

logger.info("Processing user %s", user_id)
logger.error("Failed to process user: %s", e, exc_info=True)
```

### 2.2 Module-Level Logger

Create one logger per module:

**✅ CORRECT:**
```python
"""User authentication module."""
import logging

logger = logging.getLogger(__name__)  # __name__ = 'myproject.auth'

def authenticate_user(email: str, password: str) -> User | None:
    logger.info("Authentication attempt for email: %s", email)
    try:
        user = fetch_user(email)
        if verify_password(password, user.password_hash):
            logger.info("Authentication successful for user_id: %s", user.id)
            return user
        else:
            logger.warning("Authentication failed: invalid password for email: %s", email)
            return None
    except UserNotFoundError:
        logger.warning("Authentication failed: user not found for email: %s", email)
        return None
```

**Why `__name__`:**
- Creates hierarchical logger names (`myproject.auth`)
- Enables filtering by module in configuration
- Shows exactly where the log came from

---

## 3. Log Levels

### 3.1 Level Definitions

Use the correct level for each situation:

| Level | When to Use | Example |
|-------|-------------|---------|
| **DEBUG** | Detailed diagnostic info for developers | Variable values, loop iterations, function entry/exit |
| **INFO** | General informational messages | Service started, request processed, task completed |
| **WARNING** | Something unexpected but not an error | Deprecated API used, fallback triggered, unusual condition |
| **ERROR** | Error that prevented an operation | Database connection failed, file not found, validation error |
| **CRITICAL** | System-critical failure | Service cannot start, data corruption, unrecoverable error |

### 3.2 DEBUG Level

For detailed development diagnostics:

**✅ CORRECT:**
```python
def process_data(data: DataFrame) -> DataFrame:
    logger.debug("Processing data with shape: %s", data.shape)
    
    # Expensive computation
    result = complex_transformation(data)
    
    logger.debug("Transformation complete, result shape: %s", result.shape)
    return result
```

**Use DEBUG for:**
- Function entry/exit with parameters
- Loop iterations in complex algorithms
- Intermediate calculation results
- Cache hits/misses

**Don't use DEBUG in production** (too verbose, performance impact).

### 3.3 INFO Level

For normal operational messages:

**✅ CORRECT:**
```python
def start_service():
    logger.info("Starting heat pump monitoring service")
    logger.info("Connecting to database: %s", config.database_url)
    logger.info("Loading configuration from: %s", config.config_path)
    
    initialize_components()
    
    logger.info("Service started successfully on port %s", config.port)

def process_temperature_reading(sensor_id: str, temp: float):
    logger.info(
        "Temperature reading received",
        extra={"sensor_id": sensor_id, "temperature": temp, "unit": "celsius"}
    )
```

**Use INFO for:**
- Service lifecycle (start, stop, reload)
- Significant operations completed
- Configuration loaded
- User actions (login, logout, data submitted)
- Scheduled task execution

### 3.4 WARNING Level

For recoverable issues or unexpected situations:

**✅ CORRECT:**
```python
def get_cache_value(key: str) -> Any | None:
    try:
        return cache[key]
    except KeyError:
        logger.warning("Cache miss for key: %s", key)
        return None

def load_config(path: Path) -> Config:
    if not path.exists():
        logger.warning(
            "Config file not found: %s, using defaults",
            path
        )
        return Config.default()
    
    return Config.from_file(path)

def process_api_response(response):
    if response.status_code != 200:
        logger.warning(
            "Unexpected API response code: %s, retrying",
            response.status_code
        )
        # Retry logic...
```

**Use WARNING for:**
- Fallback to defaults
- Retryable failures
- Deprecated feature usage
- Resource limits approaching
- Data anomalies that don't block processing

### 3.5 ERROR Level

For failures that prevent an operation from completing:

**✅ CORRECT:**
```python
def save_report(report: Report, path: Path):
    try:
        path.write_text(report.to_json())
        logger.info("Report saved to: %s", path)
    except PermissionError as e:
        logger.error(
            "Failed to save report: insufficient permissions for %s",
            path,
            exc_info=True  # Include stack trace
        )
        raise

def fetch_user_data(user_id: int) -> User:
    try:
        response = api_client.get(f"/users/{user_id}")
        response.raise_for_status()
        return User.from_dict(response.json())
    except HTTPError as e:
        logger.error(
            "Failed to fetch user data for user_id: %s, status: %s",
            user_id,
            e.response.status_code,
            exc_info=True
        )
        raise UserFetchError(f"Could not fetch user {user_id}") from e
```

**Use ERROR for:**
- Operations that failed and cannot proceed
- Database connection failures
- File I/O errors
- API request failures
- Validation failures that block processing

**Always include `exc_info=True`** when logging exceptions to capture stack trace.

### 3.6 CRITICAL Level

For system-critical failures that may require immediate attention:

**✅ CORRECT:**
```python
def initialize_database():
    try:
        engine = create_engine(config.database_url)
        engine.connect()
        logger.info("Database connection established")
    except Exception as e:
        logger.critical(
            "CRITICAL: Cannot connect to database, service cannot start",
            exc_info=True
        )
        sys.exit(1)  # Cannot continue

def verify_data_integrity():
    corrupted_records = check_data_integrity()
    if corrupted_records:
        logger.critical(
            "CRITICAL: Data corruption detected, %d records affected",
            len(corrupted_records),
            extra={"corrupted_record_ids": corrupted_records}
        )
        # Trigger alerts, possibly shut down
```

**Use CRITICAL for:**
- Service cannot start
- Data corruption
- Security breaches
- Unrecoverable system failures

---

## 4. What to Log

### 4.1 Always Log

**Service lifecycle:**
```python
logger.info("Service starting with config: %s", config_path)
logger.info("Service ready on port %s", port)
logger.info("Shutting down gracefully")
```

**Authentication/Authorization:**
```python
logger.info("User login attempt: email=%s", email)
logger.info("User logged in successfully: user_id=%s", user_id)
logger.warning("Failed login attempt: email=%s", email)
logger.warning("Unauthorized access attempt: user_id=%s, resource=%s", user_id, resource)
```

**Data processing operations:**
```python
logger.info("Processing batch: batch_id=%s, records=%d", batch_id, record_count)
logger.info("Batch processed successfully: batch_id=%s, duration=%.2fs", batch_id, duration)
logger.error("Batch processing failed: batch_id=%s", batch_id, exc_info=True)
```

**Configuration changes:**
```python
logger.info("Configuration reloaded from: %s", config_path)
logger.warning("Configuration validation failed, using previous config")
```

**External API calls:**
```python
logger.debug("Calling API: method=%s, url=%s", method, url)
logger.info("API request completed: status=%s, duration=%.2fs", status, duration)
logger.error("API request failed: url=%s, status=%s", url, status)
```

### 4.2 Consider Logging

**Performance metrics:**
```python
logger.info(
    "Query executed",
    extra={
        "query_type": "user_lookup",
        "duration_ms": duration * 1000,
        "result_count": len(results)
    }
)
```

**Business events:**
```python
logger.info("Order placed: order_id=%s, user_id=%s, total=%.2f", order_id, user_id, total)
logger.info("Payment processed: transaction_id=%s, amount=%.2f", txn_id, amount)
```

**Data validation:**
```python
logger.warning("Invalid data received: field=%s, value=%s", field_name, value)
```

### 4.3 Never Log

**❌ FORBIDDEN - Secrets:**
```python
logger.info("API key: %s", api_key)  # NEVER!
logger.debug("Password: %s", password)  # NEVER!
logger.info("Token: %s", auth_token)  # NEVER!
```

**❌ FORBIDDEN - Personal Identifiable Information (PII):**
```python
logger.info("Processing SSN: %s", ssn)  # NEVER!
logger.info("Credit card: %s", cc_number)  # NEVER!
logger.debug("Full name: %s %s", first_name, last_name)  # Be careful!
```

**❌ FORBIDDEN - Excessive data:**
```python
logger.info("Processing data: %s", entire_dataframe)  # Too much!
logger.debug("Response body: %s", response.text)  # Could be huge!
```

**Redact sensitive information:**
```python
def safe_log_user_info(user: User):
    logger.info(
        "User info",
        extra={
            "user_id": user.id,
            "email": mask_email(user.email),  # "a***@example.com"
            "role": user.role
        }
    )

def mask_email(email: str) -> str:
    """Mask email for logging: alice@example.com -> a***@example.com"""
    if "@" not in email:
        return "***"
    local, domain = email.split("@", 1)
    return f"{local[0]}***@{domain}"
```

---

## 5. Structured Logging

### 5.1 Use Extra Fields

Include context as structured data, not in the message:

**❌ WRONG - Unstructured:**
```python
logger.info(f"User {user_id} ordered {item_count} items totaling ${total}")
```

**✅ CORRECT - Structured:**
```python
logger.info(
    "Order placed",
    extra={
        "user_id": user_id,
        "item_count": item_count,
        "total_usd": total,
        "order_id": order_id
    }
)
```

**Benefits of structured logging:**
- Easier to search and filter
- Can aggregate metrics (average order total, etc.)
- Machine-readable
- Consistent field names across logs

### 5.2 Use String Formatting, Not f-strings

**❌ WRONG - Eager evaluation:**
```python
logger.debug(f"Processing {expensive_computation()}")  # Computed even if DEBUG disabled!
```

**✅ CORRECT - Lazy evaluation:**
```python
logger.debug("Processing %s", expensive_computation())  # Only computed if DEBUG enabled
```

**Why:** Log message formatting is deferred until the message is actually emitted. If the log level is disabled, the formatting never happens.

---

## 6. Logging Configuration

### 6.1 Basic Configuration

**Development (simple):**
```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
```

**Production (structured JSON):**
```python
import logging
import json
from datetime import datetime

class JSONFormatter(logging.Formatter):
    def format(self, record):
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
        }
        
        # Include extra fields
        if hasattr(record, 'extra'):
            log_data.update(record.extra)
        
        # Include exception if present
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_data)

# Apply to handlers
handler = logging.StreamHandler()
handler.setFormatter(JSONFormatter())
logging.root.addHandler(handler)
logging.root.setLevel(logging.INFO)
```

### 6.2 Configuration File

**Using dictConfig (production):**
```python
# logging_config.py
LOGGING_CONFIG = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'detailed': {
            'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        },
        'json': {
            'class': 'myproject.logging.JSONFormatter'
        }
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'detailed',
            'level': 'INFO'
        },
        'file': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': 'logs/app.log',
            'maxBytes': 10485760,  # 10MB
            'backupCount': 5,
            'formatter': 'json',
            'level': 'INFO'
        }
    },
    'loggers': {
        'myproject': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
            'propagate': False
        }
    },
    'root': {
        'handlers': ['console'],
        'level': 'WARNING'
    }
}

# In application startup:
from logging.config import dictConfig
dictConfig(LOGGING_CONFIG)
```

### 6.3 Environment-Based Configuration

```python
import os
import logging

def configure_logging():
    """Configure logging based on environment."""
    env = os.getenv('ENVIRONMENT', 'development')
    
    if env == 'production':
        logging.basicConfig(
            level=logging.INFO,
            format='%(message)s',  # JSON in production
            handlers=[
                logging.StreamHandler(),
                logging.handlers.RotatingFileHandler('logs/app.log', maxBytes=10_000_000, backupCount=5)
            ]
        )
    elif env == 'development':
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    else:  # test
        logging.basicConfig(level=logging.WARNING)
```

---

## 7. Performance Considerations

### 7.1 Lazy Evaluation

**❌ EXPENSIVE - Always evaluates:**
```python
logger.debug(f"Data: {expensive_serialization(data)}")
```

**✅ EFFICIENT - Only evaluates if DEBUG enabled:**
```python
logger.debug("Data: %s", expensive_serialization(data))
```

### 7.2 Check Level Before Expensive Operations

```python
if logger.isEnabledFor(logging.DEBUG):
    detailed_info = expensive_computation()
    logger.debug("Detailed info: %s", detailed_info)
```

### 7.3 Avoid Excessive Logging in Hot Paths

**❌ WRONG - Logs in tight loop:**
```python
for item in items:  # Could be millions
    logger.debug("Processing item: %s", item)
    process(item)
```

**✅ CORRECT - Log summary:**
```python
logger.info("Processing %d items", len(items))
for item in items:
    process(item)
logger.info("Completed processing %d items", len(items))
```

---

## 8. Logging in Tests

### 8.1 Capture Logs in Tests

```python
import logging

def test_function_logs_info(caplog):
    """Test that function logs expected message."""
    with caplog.at_level(logging.INFO):
        my_function()
    
    assert "Expected log message" in caplog.text
    assert any(record.levelname == "INFO" for record in caplog.records)
```

### 8.2 Suppress Logs in Tests

```python
# conftest.py
import pytest
import logging

@pytest.fixture(autouse=True)
def suppress_logs():
    """Suppress logs in tests unless PYTEST_LOGGING environment variable is set."""
    if not os.getenv("PYTEST_LOGGING"):
        logging.disable(logging.CRITICAL)
    yield
    logging.disable(logging.NOTSET)
```

---

## 9. Third-Party Library Logging

### 9.1 Control Third-Party Verbosity

```python
# Silence noisy libraries
logging.getLogger('urllib3').setLevel(logging.WARNING)
logging.getLogger('requests').setLevel(logging.WARNING)
logging.getLogger('boto3').setLevel(logging.WARNING)
```

### 9.2 Don't Silence Errors

```python
# ❌ WRONG - Hides important errors
logging.getLogger('sqlalchemy').setLevel(logging.CRITICAL)

# ✅ CORRECT - Show warnings and errors
logging.getLogger('sqlalchemy').setLevel(logging.WARNING)
```

---

## 10. Common Patterns

### 10.1 Timing Operations

```python
import time

def process_large_dataset(data):
    start_time = time.time()
    logger.info("Starting data processing: %d records", len(data))
    
    result = expensive_operation(data)
    
    duration = time.time() - start_time
    logger.info(
        "Data processing complete",
        extra={
            "record_count": len(data),
            "duration_seconds": duration,
            "records_per_second": len(data) / duration
        }
    )
    return result
```

### 10.2 Request/Response Logging

```python
def handle_request(request):
    request_id = generate_request_id()
    logger.info(
        "Request received",
        extra={
            "request_id": request_id,
            "method": request.method,
            "path": request.path,
            "user_id": request.user.id if request.user else None
        }
    )
    
    try:
        response = process_request(request)
        logger.info(
            "Request completed",
            extra={
                "request_id": request_id,
                "status_code": response.status_code,
                "duration_ms": calculate_duration()
            }
        )
        return response
    except Exception as e:
        logger.error(
            "Request failed",
            extra={"request_id": request_id},
            exc_info=True
        )
        raise
```

---

## 11. Enforcement

### 11.1 Linting Rules

```python
# Check for print() statements in production code
# Using ruff or custom script
```

```bash
# Find print statements (should use logger instead)
rg "print\(" src/ --glob '!test_*.py'
```

### 11.2 Code Review Checklist

- ✅ No `print()` statements in production code
- ✅ Appropriate log levels used
- ✅ Sensitive data not logged
- ✅ Structured logging used (extra fields)
- ✅ Exceptions logged with `exc_info=True`
- ✅ No excessive logging in loops

---

## 12. Related Rules

- **Error Handling:** Log errors at boundaries, raise for propagation
- **Clean Table Principle:** Logs should be signal, not noise
- **Security:** Never log secrets or PII

---

## 13. Summary

**Core Principles:**
- Use `logging` module, not `print()`
- Log at appropriate levels (DEBUG/INFO/WARNING/ERROR/CRITICAL)
- Use structured logging with extra fields
- Never log secrets, passwords, or PII
- Use lazy evaluation (`%s`, not f-strings)

**What to Log:**
- Service lifecycle events
- User actions (auth, important operations)
- Errors with full stack traces
- Performance metrics
- External API calls

**Configuration:**
- Development: DEBUG level, human-readable format
- Production: INFO level, JSON format, rotating files
- Tests: Suppress unless explicitly enabled

Good logging is invisible when things work, invaluable when they don't.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
