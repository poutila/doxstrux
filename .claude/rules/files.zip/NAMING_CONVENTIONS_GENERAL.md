# Code Quality Rule: CQ-003 - Naming Conventions

This project enforces consistent, meaningful naming conventions to make code self-documenting and reduce cognitive load. Names should reveal intent without requiring additional comments.

> **Hard rule:**  
> - All identifiers must follow Python naming conventions (PEP 8).  
> - Names must be descriptive and unambiguous.  
> - Abbreviations require justification and must be documented.  
> - Single-letter names only allowed in narrow contexts (loop indices, math formulas).

---

## Classification

- **Category:** Code Quality / Readability
- **Severity:** ERROR
- **Scope:** All code
- **Enforceability:** Automated (linting) + Code Review

---

## 1. Case Conventions

### 1.1 Functions and Variables: `snake_case`

**✅ CORRECT:**
```python
def calculate_total_price(items: list[Item]) -> Decimal:
    subtotal = sum(item.price for item in items)
    tax_amount = calculate_tax(subtotal)
    return subtotal + tax_amount

user_count = len(users)
is_authenticated = check_authentication(user)
max_retry_attempts = 3
```

**❌ WRONG:**
```python
def CalculateTotalPrice(items):  # Should be snake_case
    ...

def calculateTotalPrice(items):  # Should be snake_case (not camelCase)
    ...

userCount = len(users)  # Should be user_count
isAuthenticated = check()  # Should be is_authenticated
```

### 1.2 Classes: `PascalCase`

**✅ CORRECT:**
```python
class UserAccount:
    pass

class DataProcessor:
    pass

class HTTPRequestHandler:  # Acronyms stay uppercase
    pass

class XMLParser:
    pass
```

**❌ WRONG:**
```python
class user_account:  # Should be PascalCase
    pass

class dataProcessor:  # Should be PascalCase (not camelCase)
    pass

class HttpRequestHandler:  # Should be HTTPRequestHandler
    pass
```

### 1.3 Constants: `SCREAMING_SNAKE_CASE`

**✅ CORRECT:**
```python
MAX_CONNECTIONS = 100
DEFAULT_TIMEOUT = 30.0
API_BASE_URL = "https://api.example.com"
DATABASE_CONNECTION_STRING = "postgresql://localhost/db"
```

**❌ WRONG:**
```python
maxConnections = 100  # Should be SCREAMING_SNAKE_CASE
Max_Connections = 100  # Should be all uppercase
max_connections = 100  # Looks like a variable, not a constant
```

### 1.4 Private/Internal: Leading Underscore

**✅ CORRECT:**
```python
class DataProcessor:
    def __init__(self):
        self._cache = {}  # Internal implementation detail
    
    def process(self, data):
        return self._transform(data)
    
    def _transform(self, data):  # Internal helper method
        return data.lower()

# Module-level private function
def _internal_helper():
    pass
```

**❌ WRONG:**
```python
class DataProcessor:
    def __init__(self):
        self.cache = {}  # Looks public, should be _cache
    
    def internal_method(self):  # Looks public, should be _internal_method
        pass
```

### 1.5 Name Mangling: Double Underscore (Rare)

Use `__` only for true name mangling in inheritance:

**✅ CORRECT (Rare use case):**
```python
class BaseClass:
    def __init__(self):
        self.__private_state = 0  # Truly private, won't be overridden
```

**❌ AVOID unless necessary:**
```python
class MyClass:
    def __init__(self):
        self.__data = []  # Usually _data is sufficient
```

---

## 2. Descriptive Naming Patterns

### 2.1 Boolean Variables and Functions

Use `is_`, `has_`, `can_`, `should_`, `will_` prefixes:

**✅ CORRECT:**
```python
is_valid = validate_input(data)
has_permission = check_permission(user, resource)
can_edit = user.is_admin or user.id == resource.owner_id
should_retry = attempts < MAX_RETRIES
will_expire = expiry_date < datetime.now()

def is_authenticated(user) -> bool:
    return user.session is not None

def has_valid_license() -> bool:
    return license.expiry > datetime.now()

def can_access_resource(user, resource) -> bool:
    return user.role in resource.allowed_roles
```

**❌ WRONG:**
```python
valid = validate_input(data)  # Ambiguous: is it validity or validated data?
authenticated = check(user)  # Unclear: bool or User object?

def check_authentication(user):  # Returns bool? User? None?
    return user.session is not None
```

### 2.2 Functions: Verb Phrases

Functions should start with verbs that describe the action:

**✅ CORRECT:**
```python
def calculate_discount(price, percentage):
    return price * (percentage / 100)

def fetch_user_data(user_id):
    return database.query(f"SELECT * FROM users WHERE id = {user_id}")

def validate_email(email):
    return EMAIL_REGEX.match(email) is not None

def transform_to_uppercase(text):
    return text.upper()

def send_notification(user, message):
    notification_service.send(user.email, message)

def create_report(data):
    return Report(data)

def update_cache(key, value):
    cache[key] = value
```

**Common verb prefixes:**
- `get_` / `fetch_` - retrieve data
- `set_` / `update_` - modify data
- `calculate_` / `compute_` - perform calculation
- `validate_` / `check_` - verify condition
- `transform_` / `convert_` - change format
- `create_` / `build_` / `generate_` - construct new object
- `send_` / `publish_` - transmit data
- `process_` / `handle_` - general processing
- `parse_` - parse structured data
- `format_` - format data for output
- `load_` / `save_` - file I/O

**❌ WRONG:**
```python
def user_data(user_id):  # What does this do? Get? Set? Delete?
    ...

def discount(price):  # Noun, not verb - unclear action
    ...

def email(address):  # Is this validating? Sending? Getting?
    ...
```

### 2.3 Mutating vs Non-Mutating Functions

**Pattern:**
- Mutating: `update_`, `modify_`, `add_to_`, `remove_from_`
- Non-mutating: `updated`, `with_`, `without_`, returns new object

**✅ CORRECT:**
```python
# Mutating (modifies in place)
def update_prices(items: list[Item], factor: float) -> None:
    """Update prices in place."""
    for item in items:
        item.price *= factor

# Non-mutating (returns new)
def with_updated_prices(items: list[Item], factor: float) -> list[Item]:
    """Return new list with updated prices."""
    return [Item(item.name, item.price * factor) for item in items]

# Mutating
def add_item(basket: Basket, item: Item) -> None:
    basket.items.append(item)

# Non-mutating
def with_item(basket: Basket, item: Item) -> Basket:
    return Basket(basket.items + [item])
```

### 2.4 Collections: Plural Names

**✅ CORRECT:**
```python
users = fetch_all_users()
items = basket.get_items()
errors = validate_data(input_data)
prices = [item.price for item in items]
user_ids = [user.id for user in users]
```

**❌ WRONG:**
```python
user = fetch_all_users()  # Should be plural: users
item = basket.get_items()  # Should be plural: items
error = validate_data(input_data)  # Should be plural: errors
```

### 2.5 Avoid Meaningless Names

**❌ FORBIDDEN:**
```python
def process_data(data):  # Too vague
    ...

def handle_thing(thing):  # "thing" is meaningless
    ...

def do_stuff(obj):  # What stuff?
    ...

temp = calculate()  # Temporary what?
result = process()  # Result of what?
data = load()  # What data?
value = get()  # What value?
```

**✅ CORRECT:**
```python
def normalize_temperatures(readings):
    ...

def validate_user_input(form_data):
    ...

def calculate_tax_amount(subtotal):
    ...

normalized_temp = normalize(raw_temperature)
validation_errors = validate(user_input)
tax_amount = calculate_tax(subtotal)
```

---

## 3. Domain-Specific Naming

### 3.1 Use Domain Language

Name things using the vocabulary of your problem domain:

**✅ CORRECT (E-commerce domain):**
```python
class ShoppingCart:
    def add_item(self, product, quantity):
        ...
    
    def apply_discount_code(self, code):
        ...
    
    def calculate_total_with_tax(self):
        ...

class Order:
    def mark_as_shipped(self):
        ...
```

**✅ CORRECT (Data processing domain):**
```python
class DataPipeline:
    def extract_from_source(self, source):
        ...
    
    def transform_records(self, records):
        ...
    
    def load_to_warehouse(self, data):
        ...
```

### 3.2 Consistent Terminology

Use the same word for the same concept throughout the codebase:

**❌ INCONSISTENT:**
```python
def get_user(user_id):
    ...

def fetch_customer(customer_id):  # User and customer are the same
    ...

def retrieve_account(account_id):  # Again, same concept
    ...
```

**✅ CONSISTENT:**
```python
def get_user(user_id):
    ...

def get_user_by_email(email):
    ...

def get_all_users():
    ...
```

---

## 4. Context-Appropriate Names

### 4.1 Loop Variables

**✅ ACCEPTABLE (Short loops):**
```python
for i in range(10):
    print(i)

for x, y in coordinates:
    plot_point(x, y)

for key, value in mapping.items():
    process(key, value)
```

**✅ CORRECT (Complex loops):**
```python
for user_index in range(len(users)):
    user = users[user_index]
    process_user(user)

for temperature_celsius in temperature_readings:
    fahrenheit = celsius_to_fahrenheit(temperature_celsius)
    display(fahrenheit)
```

### 4.2 Mathematical Formulas

Single letters acceptable when matching mathematical notation:

**✅ CORRECT:**
```python
def calculate_distance(x1, y1, x2, y2):
    """Calculate Euclidean distance between two points."""
    return math.sqrt((x2 - x1)**2 + (y2 - y1)**2)

def solve_quadratic(a, b, c):
    """Solve ax² + bx + c = 0."""
    discriminant = b**2 - 4*a*c
    return (-b + math.sqrt(discriminant)) / (2*a)
```

### 4.3 Lambda Functions

**✅ ACCEPTABLE:**
```python
sorted_items = sorted(items, key=lambda x: x.price)
filtered = filter(lambda x: x > 0, values)
```

**✅ BETTER (Named function when complex):**
```python
def get_item_price(item):
    return item.price

sorted_items = sorted(items, key=get_item_price)
```

---

## 5. Abbreviations and Acronyms

### 5.1 Avoid Abbreviations

**❌ WRONG:**
```python
usr = get_user()  # Should be: user
conn = create_connection()  # Should be: connection
cfg = load_config()  # Should be: config
auth = authenticate()  # Should be: authentication
proc = process_data()  # Should be: processor
```

**✅ CORRECT:**
```python
user = get_user()
connection = create_connection()
config = load_config()
authentication = authenticate()
processor = process_data()
```

### 5.2 Acceptable Abbreviations

Some abbreviations are universally understood:

**✅ ACCEPTABLE:**
```python
id = user.id  # ID is universally understood
url = "https://example.com"  # URL is standard
html = generate_html()  # HTML is standard
json_data = parse_json()  # JSON is standard
api = create_api_client()  # API is standard
dto = DataTransferObject()  # DTO is standard in some contexts
```

### 5.3 Domain-Specific Acronyms

Document acronyms in domain vocabulary:

**✅ CORRECT (with documentation):**
```python
# Module docstring
"""
Heat pump monitoring system.

Acronyms:
- COP: Coefficient of Performance
- SCOP: Seasonal Coefficient of Performance
- EER: Energy Efficiency Ratio
"""

def calculate_cop(heating_output, electrical_input):
    """Calculate Coefficient of Performance (COP)."""
    return heating_output / electrical_input

def get_scop_rating(annual_heating, annual_consumption):
    """Calculate Seasonal Coefficient of Performance (SCOP)."""
    return annual_heating / annual_consumption
```

---

## 6. Special Cases

### 6.1 Type Variables

**✅ CORRECT:**
```python
from typing import TypeVar

T = TypeVar('T')  # Generic type
K = TypeVar('K')  # Key type
V = TypeVar('V')  # Value type
T_co = TypeVar('T_co', covariant=True)  # Covariant type

# Or descriptive names for domain types
UserT = TypeVar('UserT', bound=User)
DataFrameT = TypeVar('DataFrameT', bound=pl.DataFrame)
```

### 6.2 Fixtures and Test Data

**✅ CORRECT:**
```python
@pytest.fixture
def sample_user():
    return User(id=1, name="Alice")

@pytest.fixture
def mock_database():
    return MockDatabase()

def test_user_creation_with_valid_data():
    user = create_user("alice@example.com")
    assert user.email == "alice@example.com"
```

### 6.3 Exception Names

**✅ CORRECT:**
```python
class ValidationError(Exception):  # Ends with Error
    pass

class ResourceNotFoundException(Exception):  # Clear what failed
    pass

class StaleFactsError(Exception):  # Domain-specific
    pass
```

---

## 7. File and Module Names

### 7.1 Module Names: `snake_case`

**✅ CORRECT:**
```python
# user_service.py
# data_processor.py
# email_validator.py
# http_client.py
```

**❌ WRONG:**
```python
# UserService.py (should be snake_case)
# dataProcessor.py (should be snake_case)
# email-validator.py (should use underscore, not hyphen)
```

### 7.2 Package Names: Short, `snake_case`

**✅ CORRECT:**
```
myproject/
  core/
  services/
  utils/
  data_processing/
```

**❌ AVOID:**
```
myproject/
  Core/  # Should be lowercase
  myProjectServices/  # Should be snake_case
  data-processing/  # Should use underscore
```

---

## 8. Enforcement

### 8.1 Automated Linting

**Ruff configuration:**
```toml
[tool.ruff]
select = [
    "N",  # pep8-naming
]

[tool.ruff.lint.pep8-naming]
# Enforce naming conventions
classmethod-decorators = ["classmethod"]
staticmethod-decorators = ["staticmethod"]
```

**Pylint configuration:**
```toml
[tool.pylint.basic]
# Good variable names
good-names = ["i", "j", "k", "x", "y", "z", "id", "db"]

# Naming patterns
const-rgx = "[A-Z_][A-Z0-9_]*"
class-rgx = "[A-Z][a-zA-Z0-9]*"
function-rgx = "[a-z_][a-z0-9_]*"
method-rgx = "[a-z_][a-z0-9_]*"
attr-rgx = "[a-z_][a-z0-9_]*"
argument-rgx = "[a-z_][a-z0-9_]*"
variable-rgx = "[a-z_][a-z0-9_]*"
```

### 8.2 Code Review Checklist

During code review, verify:
- ✅ Names reveal intent without comments
- ✅ Consistent terminology across codebase
- ✅ Boolean names use `is_`, `has_`, `can_` prefixes
- ✅ Function names start with verbs
- ✅ No abbreviations without justification
- ✅ Collections use plural names
- ✅ Private members use leading underscore

---

## 9. Examples by Category

### 9.1 Configuration

**✅ CORRECT:**
```python
DATABASE_URL = "postgresql://localhost/db"
MAX_CONNECTIONS = 100
DEFAULT_TIMEOUT_SECONDS = 30
CACHE_TTL_MINUTES = 60
API_KEY_ENV_VAR = "MY_API_KEY"
```

### 9.2 Data Processing

**✅ CORRECT:**
```python
def normalize_temperature_readings(raw_data: pl.DataFrame) -> pl.DataFrame:
    return raw_data.with_columns(
        normalized_temp=pl.col("temperature_celsius") / 100
    )

def aggregate_daily_averages(hourly_data: pl.DataFrame) -> pl.DataFrame:
    return hourly_data.group_by("date").agg(
        avg_temperature=pl.col("temperature").mean(),
        max_temperature=pl.col("temperature").max(),
        min_temperature=pl.col("temperature").min()
    )
```

### 9.3 API/Service Layer

**✅ CORRECT:**
```python
class UserService:
    def create_user(self, email: str, password: str) -> User:
        ...
    
    def get_user_by_id(self, user_id: int) -> User | None:
        ...
    
    def update_user_profile(self, user_id: int, profile: UserProfile) -> User:
        ...
    
    def delete_user(self, user_id: int) -> None:
        ...
    
    def list_active_users(self, limit: int = 100) -> list[User]:
        ...
```

---

## 10. Related Rules

- **Type Checking Governance:** Type hints benefit from descriptive names
- **Code Complexity:** Clear names reduce need for comments
- **Documentation Standards:** Good names reduce documentation burden
- **Clean Table Principle:** Unclear names are impurities

---

## 11. Summary

**Core Principles:**
- Names should reveal intent
- Be consistent in terminology
- Use domain language
- Follow PEP 8 conventions
- Avoid abbreviations unless standard

**Case Conventions:**
- Functions/variables: `snake_case`
- Classes: `PascalCase`
- Constants: `SCREAMING_SNAKE_CASE`
- Private: `_leading_underscore`

**Naming Patterns:**
- Booleans: `is_`, `has_`, `can_`, `should_`
- Functions: verb phrases (`get_`, `calculate_`, `validate_`)
- Collections: plural names
- Mutating: `update_`, `add_to_`
- Non-mutating: `with_`, `without_`, returns new

Good names are the first line of documentation. If you need a comment to explain what a variable or function does, the name is probably wrong.

---

**Adoption Status:** ⚠️ DRAFT  
**Owner:** Architecture Team  
**Last Updated:** 2025-12-18  
**Review Cycle:** Quarterly
