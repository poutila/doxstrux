# AI Task List Linter v1.8

Deterministic linter for AI Task Lists (Spec v1.6).

## What's Fixed in v1.8

**Comment compliance loophole CLOSED:**

| Issue | Before v1.8 | After v1.8 |
|-------|-------------|------------|
| Import hygiene (R-ATL-063) | Comment with pattern passed | **$ command line required** |
| Phase Unlock scan (R-ATL-050) | Comment with `rg` passed | **$ rg command line required** |
| Spec search_tool (R-ATL-D4) | Said "MAY include" | **Fixed: MUST include** |

## Key Changes

**R-ATL-050: Phase Unlock Artifact (UPDATED)**

Must have actual `$` command lines, not comments:
```bash
$ cat > .phase-0.complete.json << EOF
{"phase": 0}
EOF

$ rg '\[\[PH:' .phase-0.complete.json && exit 1 || true
```

Comments like `# rg '\[\[PH:' ...` do NOT satisfy the requirement.

**R-ATL-063: Import hygiene (UPDATED)**

Must have actual `$` command lines, not comments:
```bash
$ rg 'from \.\.' src/ && exit 1 || true    # Multi-dot relative imports
$ rg 'import \*' src/ && exit 1 || true    # Wildcard imports
```

Comments like `# rg 'from \.\.' ...` do NOT satisfy the requirement.

**R-ATL-D4: search_tool (FIXED)**

Spec now consistently says `search_tool` is REQUIRED (removed "MAY include" language).

## Run

```bash
# Standard lint
uv run python ai_task_list_linter_v1_8.py PROJECT_TASKS.md

# With captured evidence header enforcement
uv run python ai_task_list_linter_v1_8.py --require-captured-evidence PROJECT_TASKS.md
```

Exit codes: 0 = pass, 1 = lint violations, 2 = usage/internal error

## Required YAML Front Matter

```yaml
ai_task_list:
  schema_version: "1.6"    # Must be exactly "1.6"
  mode: "instantiated"     # or "template"
  runner: "uv"
  runner_prefix: "uv run"
  search_tool: "rg"        # REQUIRED (not optional)
```

## Test Results

```
✅ Template v6 passes
✅ Valid v1.6 document passes
✅ Comment compliance REJECTED (import hygiene patterns in comments)
✅ Comment compliance REJECTED (Phase Unlock scan in comments)
✅ Schema version 1.5 rejected (requires 1.6)
✅ Spec search_tool consistency (MUST include, not MAY)
```

## Migration from v1.7

1. Update `schema_version` to `"1.6"`
2. Ensure import hygiene patterns are actual `$` command lines (not comments)
3. Ensure Phase Unlock placeholder scan is actual `$ rg` command line (not comment)

## Design Philosophy

v1.8 closes the "comment compliance" loophole identified by strict validation:

> "Some enforcement can be satisfied via comments/prose because the linter checks for string presence in section text rather than requiring them as $ command lines."

Now the linter verifies that required patterns appear in actual `$` command lines inside fenced code blocks, not just anywhere in the section text.

## Remaining Reality Limitations

As noted in external validation:
- A deterministic linter cannot prove outputs were actually produced
- True "reality verification" requires execution/evidence-capture tooling
- The spec acknowledges headers as "not cryptographically verifiable"

The recommended operational practice is to make `--require-captured-evidence` mandatory in CI for instantiated task lists.
