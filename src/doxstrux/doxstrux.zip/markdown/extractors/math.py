"""Math extractor - Extract blockquotes with nested structure analysis.

This module extracts blockquote elements from the markdown AST, including:
- Blockquote content and line ranges
- Nested structure summaries (lists, tables, code blocks)
- Section attribution for context

Functions:
    extract_blockquotes: Extract all blockquotes with metadata
"""

from typing import Any
from pprint import pprint

equation = r"$\alpha = \frac{1}{2}$"
equation = r"""
Inline example: $E = mc^2$.

Display math:

$$
\int_0^1 x^2\,dx = \tfrac{1}{3}
$$

And a fenced block:

```math
a^2 + b^2 = c^2
"""
from markdown_it import MarkdownIt
from mdit_py_plugins.texmath import texmath_plugin
# md = MarkdownIt("commonmark").use(texmath_plugin, delimiter="$")
# tokens =md.parse(equation)

def extract_math(
    tokens: list[Any],
) -> list[dict]:
    md = MarkdownIt("commonmark").use(texmath_plugin, delimiters="dollars")
    tokens =md.parse(equation)

    found = []
    for tok in tokens:
        # pprint(tok.as_dict())
        # print(f"\nToken type: {tok.type}, content: {getattr(tok, 'content', None)}, info: {getattr(tok, 'info', None)}")
        # if getattr(tok, 'children', None) is not None:
        #     print(f"  ########## Children: {[child.type for child in tok.children]}")
        #     print("  ########## Full children details:")
        if tok.type == "math_block":
            found.append({"kind": "texmath_block", "content": tok.content.strip()})

        # ```math fenced blocks
        if tok.type == "fence" and tok.info.strip() == "math":
            found.append({"kind": "fence_math", "content": tok.content.strip()})

        # Look for $ … $ inline math inside inline container children
        if tok.children:
            for child in tok.children:
                if child.type == "math_inline":
                    found.append({"kind": "texmath_inline", "content": child.content})


    pprint(found)
    return found