---
title: Math Minimal
md_flavor: math
---

# Intro
This file tests inline $e^{i\pi}+1=0$ and one display block.

$$
\int_{-\infty}^{\infty} e^{-x^2}\,dx = \sqrt{\pi}
$$

A code fence that uses dollars but is NOT math:

```python
price = f"${{amount:.2f}}"
```

End.
