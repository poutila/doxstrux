+++
title = "Refactored html 03"
id = "ref_html_03"
note = "html-case"
+++
# Refactored html 03

<div><span>broken

<span>inline HTML</span> paragraph.
