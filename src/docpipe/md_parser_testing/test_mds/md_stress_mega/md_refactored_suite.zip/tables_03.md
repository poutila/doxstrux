---
title: "Refactored tables 03"
id: ref_tables_03
note: tables-case
---
# Refactored tables 03

| H1 | H2 | H3 | H4 | H5 | H6 |
|:--:|---:|:--:|---:|---:|:---|
| 1\\:1 hotel yankee | 1:2 quebec kilo uniform | 1\\:3 sierra november | 1:4 echo | 1\\:5 hotel lima india | 1:6 echo |
| 2\\:1 romeo papa victor | 2:2 victor yankee | 2\\:3 india | 2:4 juliet victor kilo | 2\\:5 foxtrot | 2:6 kilo yankee delta |
| 3\\:1 bravo uniform echo | 3:2 uniform | 3\\:3 golf zulu papa | 3:4 whiskey | 3\\:5 lima november foxtrot | 3:6 golf |
| 4\\:1 sierra | 4:2 lima foxtrot sierra | 4\\:3 zulu kilo | 4:4 whiskey | 4\\:5 delta sierra |
| 5\\:1 bravo oscar | 5:2 papa november | 5\\:3 zulu juliet | 5:4 hotel xray echo | 5\\:5 juliet tango | 5:6 quebec alpha |
| 6\\:1 november zulu | 6:2 xray mike lima | 6\\:3 uniform charlie | 6:4 xray india | 6\\:5 papa | 6:6 quebec lima | 6\\:7 hotel |
| 7\\:1 delta quebec | 7:2 delta charlie delta | 7\\:3 golf papa yankee | 7:4 yankee whiskey | 7\\:5 kilo hotel | 7:6 zulu juliet | 7\\:7 charlie kilo papa |
| 8\\:1 zulu alpha alpha | 8:2 delta | 8\\:3 golf sierra | 8:4 india quebec lima | 8\\:5 india quebec mike |
| 9\\:1 foxtrot india alpha | 9:2 yankee | 9\\:3 romeo juliet | 9:4 xray | 9\\:5 papa |

| H1 | H2 | H3 | H4 |
|---:|----|---:|:--:|
| 1:1 kilo golf charlie | 1:2 foxtrot hotel kilo | 1:3 delta romeo delta | 1:4 victor charlie |
| 2:1 foxtrot | 2:2 bravo golf | 2:3 november | 2:4 golf zulu yankee |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tables_04.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
