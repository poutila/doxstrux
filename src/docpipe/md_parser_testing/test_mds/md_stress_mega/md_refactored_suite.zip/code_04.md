{"title":"Refactored code 04","id":"ref_code_04","note":"code-case"}
# Refactored code 04
Title
=====

Sub
----


```md
print('x')
```


~~~bash
echo hello
~~~


Text with `inline` code and ``weird`` backticks.
