---
title: "Refactored images 04"
id: ref_images_04
note: images-case
---
# Refactored images 04
Title
=====

Sub
----


![ok0](https://via.placeholder.com/64 "t0")
![rel0](./assets/img_0.png)
![rel1](./assets/img_1.png)
![d0](data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="8" height="8"></svg>)

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./images_05.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
