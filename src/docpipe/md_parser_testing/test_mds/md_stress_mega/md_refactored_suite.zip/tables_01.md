+++
title = "Refactored tables 01"
id = "ref_tables_01"
note = "tables-case"
+++
# Refactored tables 01
Title
=====

Sub
----


| H1 | H2 | H3 | H4 | H5 | H6 | H7 |
|:--:|:--:|:---|----|:--:|:---|:--:|
| 1\\:1 tango | 1:2 hotel | 1\\:3 foxtrot november alpha | 1:4 quebec romeo | 1\\:5 delta whiskey | 1:6 kilo juliet bravo | 1\\:7 papa lima kilo | 1:8 yankee |
| 2\\:1 sierra kilo whiskey | 2:2 delta | 2\\:3 alpha whiskey bravo | 2:4 whiskey quebec | 2\\:5 bravo zulu | 2:6 alpha uniform | 2\\:7 victor |
| 3\\:1 oscar charlie kilo | 3:2 quebec tango oscar | 3\\:3 quebec golf charlie | 3:4 sierra victor | 3\\:5 xray lima | 3:6 echo | 3\\:7 delta | 3:8 zulu |
| 4\\:1 echo | 4:2 victor | 4\\:3 mike papa | 4:4 charlie lima | 4\\:5 golf foxtrot tango | 4:6 india zulu | 4\\:7 zulu charlie victor | 4:8 papa india |
| 5\\:1 delta yankee golf | 5:2 whiskey | 5\\:3 foxtrot echo bravo | 5:4 alpha bravo hotel | 5\\:5 delta juliet | 5:6 victor |
| 6\\:1 quebec november tango | 6:2 sierra mike xray | 6\\:3 charlie golf | 6:4 whiskey | 6\\:5 whiskey golf |
| 7\\:1 hotel delta juliet | 7:2 kilo juliet kilo | 7\\:3 bravo india | 7:4 kilo kilo | 7\\:5 charlie uniform romeo |
| 8\\:1 india bravo kilo | 8:2 echo | 8\\:3 papa papa | 8:4 zulu sierra kilo | 8\\:5 tango | 8:6 quebec victor | 8\\:7 oscar |
| 9\\:1 golf whiskey romeo | 9:2 xray juliet | 9\\:3 zulu | 9:4 papa victor tango | 9\\:5 november sierra oscar |
| 10\\:1 mike xray | 10:2 foxtrot charlie | 10\\:3 kilo echo | 10:4 uniform sierra | 10\\:5 whiskey quebec | 10:6 delta delta |
| 11\\:1 lima | 11:2 november echo quebec | 11\\:3 uniform | 11:4 quebec | 11\\:5 whiskey lima | 11:6 november romeo alpha |

| H1 | H2 | H3 | H4 |
|----|----|----|:---|
| 1:1 bravo | 1:2 hotel yankee echo | 1:3 whiskey | 1:4 whiskey |
| 2:1 xray | 2:2 tango | 2:3 sierra | 2:4 tango alpha sierra |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tables_02.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
