+++
title = "Refactored quotes 03"
id = "ref_quotes_03"
note = "quotes-case"
+++
# Refactored quotes 03
Title
=====

Sub
----



> Quote level 1
> > Nested level 2 with a list:
> > - a
> > - b
> >
> > And a table:
> > 
> > | Q | V |
> > |---|---|
> > | 1 | 2 |
>
> Fenced code:
>
> ```json
> {"a":1}
> ```


[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./quotes_04.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt)
