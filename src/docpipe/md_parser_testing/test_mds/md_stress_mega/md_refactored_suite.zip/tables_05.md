{"title":"Refactored tables 05","id":"ref_tables_05","note":"tables-case"}
# Refactored tables 05
Title
=====

Sub
----


| H1 | H2 | H3 | H4 | H5 | H6 | H7 | H8 |
|---|---|---|---|---|---|---|---|
| 1\\:1 bravo foxtrot | 1:2 quebec yankee sierra | 1\\:3 kilo | 1:4 tango hotel | 1\\:5 charlie | 1:6 xray delta sierra | 1\\:7 foxtrot |
| 2\\:1 zulu kilo | 2:2 lima quebec delta | 2\\:3 hotel victor oscar | 2:4 november xray | 2\\:5 juliet mike foxtrot | 2:6 victor | 2\\:7 tango echo |
| 3\\:1 zulu golf | 3:2 golf kilo | 3\\:3 uniform | 3:4 kilo uniform romeo | 3\\:5 november yankee | 3:6 quebec | 3\\:7 golf | 3:8 romeo india foxtrot |
| 4\\:1 golf zulu | 4:2 hotel echo | 4\\:3 golf november | 4:4 november | 4\\:5 whiskey | 4:6 uniform foxtrot | 4\\:7 bravo alpha | 4:8 tango | 4\\:9 oscar yankee india |
| 5\\:1 india | 5:2 foxtrot | 5\\:3 kilo echo whiskey | 5:4 victor xray sierra | 5\\:5 xray juliet | 5:6 tango xray juliet | 5\\:7 tango zulu | 5:8 lima india | 5\\:9 tango |
| 6\\:1 tango lima quebec | 6:2 papa tango | 6\\:3 whiskey echo tango | 6:4 mike | 6\\:5 echo | 6:6 charlie uniform hotel | 6\\:7 hotel | 6:8 zulu sierra |
| 7\\:1 sierra lima | 7:2 tango | 7\\:3 golf yankee yankee | 7:4 alpha juliet | 7\\:5 lima india papa | 7:6 lima | 7\\:7 charlie | 7:8 xray foxtrot zulu |
| 8\\:1 echo hotel | 8:2 india juliet golf | 8\\:3 victor charlie sierra | 8:4 charlie juliet bravo | 8\\:5 whiskey | 8:6 delta xray | 8\\:7 mike bravo quebec | 8:8 mike yankee echo |

| H1 | H2 | H3 | H4 |
|:--:|:---|:--:|---:|
| 1:1 golf | 1:2 victor | 1:3 juliet echo | 1:4 quebec quebec victor |
| 2:1 uniform | 2:2 india romeo | 2:3 yankee delta | 2:4 foxtrot papa |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tables_01.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
