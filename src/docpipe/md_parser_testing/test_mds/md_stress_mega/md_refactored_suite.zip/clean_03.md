---
title: "Refactored clean 03"
id: ref_clean_03
note: clean-case
---
# Refactored clean 03
Title
=====

Sub
----


A simple paragraph with victor victor uniform tango india whiskey golf golf echo papa mike tango.

- list level 1
  * list level 2
    - list level 3
      * list level 4
        - list level 5
              code in list

| H1 | H2 | H3 | H4 |
|---:|----|:--:|----|
| 1:1 whiskey | 1:2 tango whiskey | 1:3 kilo bravo alpha | 1:4 tango golf uniform |
| 2:1 juliet yankee | 2:2 kilo yankee mike | 2:3 hotel juliet | 2:4 sierra mike |
| 3:1 mike echo tango | 3:2 yankee xray | 3:3 mike | 3:4 charlie oscar whiskey |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./clean_04.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./clean_04.md#sec2)
