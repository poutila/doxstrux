---
title: "Refactored frontmatter 03"
id: ref_frontmatter_03
note: frontmatter-case
---
# Refactored frontmatter 03

Front matter variant above; plus wiki links: [[Page One]] and [[Page Two|Alias]].

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./frontmatter_04.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
