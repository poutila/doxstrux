+++
title = "Refactored tasks 05"
id = "ref_tasks_05"
note = "tasks-case"
+++
# Refactored tasks 05

- list level 1
  - [x] task level 2
    - [ ] task level 3
      - [x] task level 4
        - list level 5
          - [x] task level 6
            - list level 7
                  code in list
              	indented with tab

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tasks_01.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt)

![ok0](https://via.placeholder.com/64 "t0")
