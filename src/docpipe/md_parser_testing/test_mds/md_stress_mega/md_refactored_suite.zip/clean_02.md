---
title: "Refactored clean 02"
id: ref_clean_02
note: clean-case
---
# Refactored clean 02
Title
=====

Sub
----


A simple paragraph with oscar xray zulu sierra kilo alpha zulu tango kilo november sierra zulu.

- list level 1
  * list level 2
    - list level 3
          code in list

| H1 | H2 | H3 | H4 | H5 |
|:--:|:--:|:---|----|----|
| 1:1 zulu | 1:2 papa romeo yankee | 1:3 xray lima xray | 1:4 zulu sierra uniform | 1:5 india charlie |
| 2:1 echo bravo foxtrot | 2:2 charlie golf | 2:3 romeo india | 2:4 romeo | 2:5 november |
| 3:1 tango whiskey | 3:2 november | 3:3 xray echo | 3:4 uniform | 3:5 lima mike |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./clean_03.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./clean_03.md#sec2)
