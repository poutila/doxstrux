{"title":"Refactored tables 02","id":"ref_tables_02","note":"tables-case"}
# Refactored tables 02

| H1 | H2 | H3 | H4 | H5 | H6 | H7 | H8 | H9 | H10 |
|---:|:--:|---:|---:|---:|---:|----|---:|:--:|:---|
| 1\\:1 november | 1:2 mike hotel | 1\\:3 yankee uniform | 1:4 hotel | 1\\:5 whiskey | 1:6 quebec foxtrot mike | 1\\:7 yankee tango | 1:8 kilo india oscar | 1\\:9 charlie | 1:10 romeo | 1\\:11 india kilo oscar |
| 2\\:1 juliet sierra hotel | 2:2 papa mike delta | 2\\:3 bravo yankee | 2:4 yankee | 2\\:5 quebec | 2:6 india sierra oscar | 2\\:7 oscar foxtrot | 2:8 victor alpha victor |
| 3\\:1 oscar mike tango | 3:2 sierra bravo hotel | 3\\:3 zulu papa uniform | 3:4 romeo foxtrot papa | 3\\:5 india juliet sierra | 3:6 papa | 3\\:7 juliet mike romeo | 3:8 sierra romeo | 3\\:9 november november bravo | 3:10 kilo |
| 4\\:1 mike kilo delta | 4:2 hotel hotel lima | 4\\:3 foxtrot uniform | 4:4 hotel kilo | 4\\:5 papa | 4:6 charlie uniform | 4\\:7 romeo | 4:8 golf |
| 5\\:1 quebec | 5:2 sierra uniform | 5\\:3 victor delta | 5:4 zulu | 5\\:5 echo | 5:6 hotel sierra xray | 5\\:7 lima | 5:8 papa quebec tango | 5\\:9 golf |
| 6\\:1 kilo quebec echo | 6:2 romeo romeo | 6\\:3 kilo romeo | 6:4 india delta | 6\\:5 juliet delta | 6:6 bravo | 6\\:7 yankee | 6:8 india xray india |
| 7\\:1 echo hotel echo | 7:2 foxtrot delta quebec | 7\\:3 lima | 7:4 uniform india yankee | 7\\:5 foxtrot | 7:6 india quebec november | 7\\:7 november alpha | 7:8 whiskey golf |

| H1 | H2 | H3 | H4 |
|---:|---:|----|:---|
| 1:1 romeo quebec india | 1:2 kilo | 1:3 quebec kilo papa | 1:4 echo november |
| 2:1 india oscar victor | 2:2 sierra echo quebec | 2:3 lima zulu | 2:4 uniform |
| 3:1 tango kilo papa | 3:2 india | 3:3 tango echo yankee | 3:4 juliet yankee |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tables_03.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
