{"title":"Refactored tasks 04","id":"ref_tasks_04","note":"tasks-case"}
# Refactored tasks 04
Title
=====

Sub
----


- list level 1
  - [x] task level 2
    - [ ] task level 3
          code in list

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tasks_05.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt)

![ok0](https://via.placeholder.com/64 "t0")
