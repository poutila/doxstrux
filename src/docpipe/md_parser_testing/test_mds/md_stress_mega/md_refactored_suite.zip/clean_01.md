{"title":"Refactored clean 01","id":"ref_clean_01","note":"clean-case"}
# Refactored clean 01

A simple paragraph with whiskey lima sierra sierra xray foxtrot yankee kilo mike uniform zulu lima.

- list level 1
  * list level 2
    - list level 3
      * list level 4
            code in list
        	indented with tab

| H1 | H2 | H3 | H4 |
|:---|----|----|:---|
| 1:1 whiskey victor lima | 1:2 mike zulu | 1:3 zulu juliet victor | 1:4 lima |
| 2:1 delta oscar hotel | 2:2 zulu | 2:3 victor whiskey | 2:4 oscar tango india |
| 3:1 romeo | 3:2 uniform | 3:3 tango sierra yankee | 3:4 charlie |
| 4:1 uniform tango | 4:2 victor | 4:3 uniform | 4:4 golf |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./clean_02.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./clean_02.md#sec2)
