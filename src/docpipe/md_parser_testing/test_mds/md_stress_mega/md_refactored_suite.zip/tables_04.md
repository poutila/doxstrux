{"title":"Refactored tables 04","id":"ref_tables_04","note":"tables-case"}
# Refactored tables 04

| H1 | H2 | H3 | H4 |
|:--:|:--:|---:|---:|
| 1\\:1 zulu | 1:2 papa kilo zulu | 1\\:3 bravo | 1:4 november |
| 2\\:1 uniform | 2:2 alpha quebec yankee | 2\\:3 uniform | 2:4 yankee lima xray | 2\\:5 uniform |
| 3\\:1 oscar november whiskey | 3:2 alpha victor | 3\\:3 golf | 3:4 hotel kilo | 3\\:5 tango yankee alpha |
| 4\\:1 hotel | 4:2 charlie echo | 4\\:3 echo november | 4:4 november papa | 4\\:5 alpha charlie |
| 5\\:1 alpha | 5:2 mike | 5\\:3 hotel |
| 6\\:1 india romeo foxtrot | 6:2 hotel india zulu | 6\\:3 golf romeo |
| 7\\:1 kilo papa | 7:2 victor papa alpha |

| H1 | H2 | H3 | H4 | H5 |
|----|----|---:|:---|---:|
| 1:1 uniform charlie | 1:2 juliet | 1:3 oscar india uniform | 1:4 uniform bravo | 1:5 golf quebec |
| 2:1 golf | 2:2 bravo whiskey delta | 2:3 uniform | 2:4 india india india | 2:5 foxtrot whiskey |
| 3:1 zulu golf oscar | 3:2 papa echo charlie | 3:3 delta | 3:4 november | 3:5 bravo romeo |
| 4:1 charlie zulu | 4:2 quebec alpha | 4:3 bravo mike | 4:4 bravo mike hotel | 4:5 november kilo uniform |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./tables_05.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
