---
title: "Refactored code 03"
id: ref_code_03
note: code-case
---
# Refactored code 03

```py
print('x')
```


~~~json
echo hello
~~~


Text with `inline` code and ``weird`` backticks.

```yaml
k: v
  z: [  # unclosed fence below
