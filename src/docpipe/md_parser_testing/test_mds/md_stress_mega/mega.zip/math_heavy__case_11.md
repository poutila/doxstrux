---
title: "Math Heavy 11"
id: math_heavy_11
md_flavor: math
allows_html: false
note: latex-mix
---
