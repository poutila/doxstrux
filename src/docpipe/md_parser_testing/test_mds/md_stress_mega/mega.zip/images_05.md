---
title: "Refactored images 05"
id: ref_images_05
note: images-case
---
# Refactored images 05
Title
=====

Sub
----


![ok0](https://via.placeholder.com/64 "t0")
![rel0](./assets/img_0.png)
[![imglink](https://via.placeholder.com/24)](https://example.com/landing)

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./images_01.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
