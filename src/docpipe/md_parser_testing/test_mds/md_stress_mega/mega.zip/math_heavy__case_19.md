---
title: "Math Heavy 19"
id: math_heavy_19
md_flavor: math
allows_html: false
note: latex-mix
---
