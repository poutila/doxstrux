---
title: "Mixed Encoding 07"
id: mixed_encoding_07
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
