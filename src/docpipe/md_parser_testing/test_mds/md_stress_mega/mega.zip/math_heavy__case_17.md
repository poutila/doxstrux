---
title: "Math Heavy 17"
id: math_heavy_17
md_flavor: math
allows_html: false
note: latex-mix
---
