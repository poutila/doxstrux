---
title: "Mixed Encoding 11"
id: mixed_encoding_11
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
