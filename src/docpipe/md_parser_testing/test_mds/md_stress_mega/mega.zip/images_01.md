{"title":"Refactored images 01","id":"ref_images_01","note":"images-case"}
# Refactored images 01

![ok0](https://via.placeholder.com/64 "t0")
![ok1](https://via.placeholder.com/74 "t1")
![ok2](https://via.placeholder.com/84 "t2")
![rel0](./assets/img_0.png)
![rel1](./assets/img_1.png)

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./images_02.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com)
