---
title: "Math Heavy 07"
id: math_heavy_07
md_flavor: math
allows_html: false
note: latex-mix
---
