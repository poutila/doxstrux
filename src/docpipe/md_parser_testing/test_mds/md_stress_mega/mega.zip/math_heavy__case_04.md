---
title: "Math Heavy 04"
id: math_heavy_04
md_flavor: math
allows_html: false
note: latex-mix
---
