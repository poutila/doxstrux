---
title: "Math Heavy 26"
id: math_heavy_26
md_flavor: math
allows_html: false
note: latex-mix
---
