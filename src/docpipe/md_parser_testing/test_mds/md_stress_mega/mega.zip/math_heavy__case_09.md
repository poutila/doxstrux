---
title: "Math Heavy 09"
id: math_heavy_09
md_flavor: math
allows_html: false
note: latex-mix
---
