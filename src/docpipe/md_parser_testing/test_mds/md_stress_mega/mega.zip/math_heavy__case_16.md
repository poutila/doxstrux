---
title: "Math Heavy 16"
id: math_heavy_16
md_flavor: math
allows_html: false
note: latex-mix
---
