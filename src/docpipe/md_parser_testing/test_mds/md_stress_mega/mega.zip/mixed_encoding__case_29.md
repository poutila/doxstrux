---
title: "Mixed Encoding 29"
id: mixed_encoding_29
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
