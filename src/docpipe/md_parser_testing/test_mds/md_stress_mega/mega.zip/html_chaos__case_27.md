---
title: "HTML Chaos 27"
id: html_chaos_27
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
