---
title: "HTML Chaos 12"
id: html_chaos_12
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
