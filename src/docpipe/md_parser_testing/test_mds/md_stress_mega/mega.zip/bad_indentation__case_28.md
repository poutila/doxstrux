---
title: "Bad Indentation 28"
id: bad_indentation_28
md_flavor: mixed
allows_html: false
note: indentation-errors
---
