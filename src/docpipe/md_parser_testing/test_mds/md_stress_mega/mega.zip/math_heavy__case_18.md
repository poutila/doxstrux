---
title: "Math Heavy 18"
id: math_heavy_18
md_flavor: math
allows_html: false
note: latex-mix
---
