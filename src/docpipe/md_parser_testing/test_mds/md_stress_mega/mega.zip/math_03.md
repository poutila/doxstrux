---
title: "Refactored math 03"
id: ref_math_03
note: math-case
---
# Refactored math 03
Title
=====

Sub
----



Inline math $E=mc^2$ and block:

$$
\int_{-\infty}^{\infty} e^{-x^2} dx = \sqrt{\pi}
$$


[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./math_04.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt)
