{"title":"Refactored linklab 01","id":"ref_linklab_01","note":"linklab-case"}
# Refactored linklab 01

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./linklab_02.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./linklab_02.md#sec2) [ext9](https://example.com/9) [mail10](mailto:user10@example.com) [file11](file:///C:/Temp/11.txt) [bad12](ht!tp://broken^12) [cross13](./linklab_02.md#sec1) [ext14](https://example.com/14) [mail15](mailto:user15@example.com) [file16](file:///C:/Temp/16.txt)

| H1 | H2 | H3 |
|---:|:--:|:--:|
| 1:1 mike bravo charlie | 1:2 foxtrot india | 1:3 foxtrot uniform |
| 2:1 delta | 2:2 quebec charlie | 2:3 foxtrot india |
| 3:1 romeo romeo hotel | 3:2 yankee romeo | 3:3 whiskey oscar |
