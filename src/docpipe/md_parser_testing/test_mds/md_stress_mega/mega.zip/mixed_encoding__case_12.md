---
title: "Mixed Encoding 12"
id: mixed_encoding_12
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
