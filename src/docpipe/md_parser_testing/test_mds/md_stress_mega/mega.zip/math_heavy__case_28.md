---
title: "Math Heavy 28"
id: math_heavy_28
md_flavor: math
allows_html: false
note: latex-mix
---
