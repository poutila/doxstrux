{"title":"Refactored html 01","id":"ref_html_01","note":"html-case"}
# Refactored html 01
Title
=====

Sub
----


<div><em>ok</em></div><span style='color:red'>inline</span>

<span>inline HTML</span> paragraph.
