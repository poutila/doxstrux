---
title: "Math Heavy 12"
id: math_heavy_12
md_flavor: math
allows_html: false
note: latex-mix
---
