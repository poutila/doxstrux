---
title: "Refactored clean 04"
id: ref_clean_04
note: clean-case
---
# Refactored clean 04
Title
=====

Sub
----


A simple paragraph with india papa quebec tango mike echo bravo quebec sierra mike golf uniform.

- list level 1
  * list level 2
    - list level 3
      * list level 4
        - list level 5
              code in list
          	indented with tab

| H1 | H2 | H3 | H4 |
|:---|----|:--:|---:|
| 1:1 kilo india sierra | 1:2 victor | 1:3 echo quebec yankee | 1:4 victor uniform bravo |
| 2:1 romeo papa juliet | 2:2 echo | 2:3 oscar | 2:4 uniform |
| 3:1 tango papa oscar | 3:2 xray alpha foxtrot | 3:3 foxtrot | 3:4 yankee |
| 4:1 uniform | 4:2 whiskey | 4:3 zulu oscar oscar | 4:4 zulu mike victor |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./clean_05.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./clean_05.md#sec2)
