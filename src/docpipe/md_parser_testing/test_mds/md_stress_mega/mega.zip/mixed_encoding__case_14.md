---
title: "Mixed Encoding 14"
id: mixed_encoding_14
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
