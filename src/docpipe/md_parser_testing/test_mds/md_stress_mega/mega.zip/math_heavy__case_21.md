---
title: "Math Heavy 21"
id: math_heavy_21
md_flavor: math
allows_html: false
note: latex-mix
---
