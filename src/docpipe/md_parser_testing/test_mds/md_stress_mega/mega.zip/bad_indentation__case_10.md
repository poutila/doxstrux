---
title: "Bad Indentation 10"
id: bad_indentation_10
md_flavor: mixed
allows_html: false
note: indentation-errors
---
