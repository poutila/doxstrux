---
title: "HTML Chaos 25"
id: html_chaos_25
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
