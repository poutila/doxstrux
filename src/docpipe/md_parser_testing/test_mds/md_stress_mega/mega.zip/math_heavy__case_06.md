---
title: "Math Heavy 06"
id: math_heavy_06
md_flavor: math
allows_html: false
note: latex-mix
---
