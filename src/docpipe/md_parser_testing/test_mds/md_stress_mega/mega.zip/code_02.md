---
title: "Refactored code 02"
id: ref_code_02
note: code-case
---
# Refactored code 02
Title
=====

Sub
----


```py
print('x')
```


~~~json
echo hello
~~~


Text with `inline` code and ``weird`` backticks.

```yaml
k: v
  z: [  # unclosed fence below
