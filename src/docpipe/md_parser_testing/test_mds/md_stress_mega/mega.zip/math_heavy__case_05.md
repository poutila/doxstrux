---
title: "Math Heavy 05"
id: math_heavy_05
md_flavor: math
allows_html: false
note: latex-mix
---
