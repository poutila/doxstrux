---
title: "Math Heavy 29"
id: math_heavy_29
md_flavor: math
allows_html: false
note: latex-mix
---
