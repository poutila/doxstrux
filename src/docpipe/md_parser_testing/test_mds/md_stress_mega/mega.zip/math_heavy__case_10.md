---
title: "Math Heavy 10"
id: math_heavy_10
md_flavor: math
allows_html: false
note: latex-mix
---
