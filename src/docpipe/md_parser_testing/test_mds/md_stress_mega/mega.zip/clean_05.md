+++
title = "Refactored clean 05"
id = "ref_clean_05"
note = "clean-case"
+++
# Refactored clean 05

A simple paragraph with alpha whiskey november lima zulu uniform delta zulu foxtrot charlie whiskey alpha.

- list level 1
  * list level 2
    - list level 3
      * list level 4
            code in list

| H1 | H2 | H3 | H4 |
|:--:|:---|:---|:--:|
| 1:1 uniform mike sierra | 1:2 hotel bravo november | 1:3 victor | 1:4 kilo romeo |
| 2:1 papa xray | 2:2 charlie | 2:3 charlie | 2:4 victor echo lima |
| 3:1 sierra mike | 3:2 alpha | 3:3 hotel bravo romeo | 3:4 delta uniform mike |

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./clean_01.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./clean_01.md#sec2)
