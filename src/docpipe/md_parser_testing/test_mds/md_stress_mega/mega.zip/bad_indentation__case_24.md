---
title: "Bad Indentation 24"
id: bad_indentation_24
md_flavor: mixed
allows_html: false
note: indentation-errors
---
