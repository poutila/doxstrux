---
title: "Math Heavy 27"
id: math_heavy_27
md_flavor: math
allows_html: false
note: latex-mix
---
