---
title: "Math Heavy 25"
id: math_heavy_25
md_flavor: math
allows_html: false
note: latex-mix
---
