+++
title = "Refactored linklab 05"
id = "ref_linklab_05"
note = "linklab-case"
+++
# Refactored linklab 05

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./linklab_01.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./linklab_01.md#sec2) [ext9](https://example.com/9) [mail10](mailto:user10@example.com) [file11](file:///C:/Temp/11.txt) [bad12](ht!tp://broken^12) [cross13](./linklab_01.md#sec1) [ext14](https://example.com/14) [mail15](mailto:user15@example.com) [file16](file:///C:/Temp/16.txt)

| H1 | H2 | H3 |
|:--:|----|:--:|
| 1:1 juliet india romeo | 1:2 foxtrot | 1:3 yankee |
| 2:1 juliet bravo | 2:2 hotel mike uniform | 2:3 oscar |
| 3:1 lima | 3:2 victor | 3:3 oscar |
