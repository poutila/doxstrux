---
title: "Refactored html 02"
id: ref_html_02
note: html-case
---
# Refactored html 02

<div><span>broken

<span>inline HTML</span> paragraph.
