---
title: "Math Heavy 22"
id: math_heavy_22
md_flavor: math
allows_html: false
note: latex-mix
---
