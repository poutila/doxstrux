---
title: "Math Heavy 08"
id: math_heavy_08
md_flavor: math
allows_html: false
note: latex-mix
---
