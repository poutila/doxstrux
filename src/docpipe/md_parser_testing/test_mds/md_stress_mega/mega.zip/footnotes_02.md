---
title: "Refactored footnotes 02"
id: ref_footnotes_02
note: footnotes-case
---
# Refactored footnotes 02

Footnote ref here[^a].

[^a]: A proper footnote.

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./footnotes_03.md#sec0) [ext4](https://example.com/4)
