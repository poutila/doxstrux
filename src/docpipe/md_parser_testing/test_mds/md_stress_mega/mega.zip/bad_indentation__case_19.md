---
title: "Bad Indentation 19"
id: bad_indentation_19
md_flavor: mixed
allows_html: false
note: indentation-errors
---
