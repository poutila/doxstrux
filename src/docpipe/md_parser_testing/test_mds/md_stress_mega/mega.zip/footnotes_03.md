---
title: "Refactored footnotes 03"
id: ref_footnotes_03
note: footnotes-case
---
# Refactored footnotes 03
Title
=====

Sub
----


Refs[^d] and again[^d].

[^d]: First.
[^d]: Second duplicate.

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./footnotes_04.md#sec0) [ext4](https://example.com/4)
