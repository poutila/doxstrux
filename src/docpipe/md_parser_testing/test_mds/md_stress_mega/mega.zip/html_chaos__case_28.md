---
title: "HTML Chaos 28"
id: html_chaos_28
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
