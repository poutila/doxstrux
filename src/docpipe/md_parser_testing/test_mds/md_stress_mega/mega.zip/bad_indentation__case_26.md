---
title: "Bad Indentation 26"
id: bad_indentation_26
md_flavor: mixed
allows_html: false
note: indentation-errors
---
