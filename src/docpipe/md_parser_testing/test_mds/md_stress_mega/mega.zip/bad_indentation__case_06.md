---
title: "Bad Indentation 06"
id: bad_indentation_06
md_flavor: mixed
allows_html: false
note: indentation-errors
---
