---
title: "Math Heavy 23"
id: math_heavy_23
md_flavor: math
allows_html: false
note: latex-mix
---
