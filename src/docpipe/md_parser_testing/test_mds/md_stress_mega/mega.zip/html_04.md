{"title":"Refactored html 04","id":"ref_html_04","note":"html-case"}
# Refactored html 04

<div><span>broken

<span>inline HTML</span> paragraph.
