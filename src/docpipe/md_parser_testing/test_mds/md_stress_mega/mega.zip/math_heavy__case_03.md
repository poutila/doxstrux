---
title: "Math Heavy 03"
id: math_heavy_03
md_flavor: math
allows_html: false
note: latex-mix
---
