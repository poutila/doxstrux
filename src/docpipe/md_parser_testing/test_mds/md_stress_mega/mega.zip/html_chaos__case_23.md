---
title: "HTML Chaos 23"
id: html_chaos_23
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
