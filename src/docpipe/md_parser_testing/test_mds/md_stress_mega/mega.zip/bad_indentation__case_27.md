---
title: "Bad Indentation 27"
id: bad_indentation_27
md_flavor: mixed
allows_html: false
note: indentation-errors
---
