---
title: "Mixed Encoding 13"
id: mixed_encoding_13
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
