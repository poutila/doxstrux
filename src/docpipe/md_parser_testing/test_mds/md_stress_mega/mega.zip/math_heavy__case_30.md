---
title: "Math Heavy 30"
id: math_heavy_30
md_flavor: math
allows_html: false
note: latex-mix
---
