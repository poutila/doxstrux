---
title: "Math Heavy 13"
id: math_heavy_13
md_flavor: math
allows_html: false
note: latex-mix
---
