---
title: "Math Heavy 02"
id: math_heavy_02
md_flavor: math
allows_html: false
note: latex-mix
---
