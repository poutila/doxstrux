---
title: "Refactored linklab 02"
id: ref_linklab_02
note: linklab-case
---
# Refactored linklab 02

[file1](file:///C:/Temp/1.txt) [bad2](ht!tp://broken^2) [cross3](./linklab_03.md#sec0) [ext4](https://example.com/4) [mail5](mailto:user5@example.com) [file6](file:///C:/Temp/6.txt) [bad7](ht!tp://broken^7) [cross8](./linklab_03.md#sec2) [ext9](https://example.com/9) [mail10](mailto:user10@example.com) [file11](file:///C:/Temp/11.txt) [bad12](ht!tp://broken^12) [cross13](./linklab_03.md#sec1) [ext14](https://example.com/14) [mail15](mailto:user15@example.com) [file16](file:///C:/Temp/16.txt)

| H1 | H2 | H3 |
|---:|:--:|---:|
| 1:1 xray delta india | 1:2 yankee alpha | 1:3 alpha bravo delta |
| 2:1 juliet lima | 2:2 papa sierra | 2:3 zulu kilo whiskey |
| 3:1 romeo lima xray | 3:2 india juliet echo | 3:3 romeo uniform hotel |
