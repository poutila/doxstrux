---
title: "Mixed Encoding 28"
id: mixed_encoding_28
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
