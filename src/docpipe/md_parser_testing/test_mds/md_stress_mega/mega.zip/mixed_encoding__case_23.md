---
title: "Mixed Encoding 23"
id: mixed_encoding_23
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
