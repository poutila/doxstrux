---
title: "Math Heavy 15"
id: math_heavy_15
md_flavor: math
allows_html: false
note: latex-mix
---
