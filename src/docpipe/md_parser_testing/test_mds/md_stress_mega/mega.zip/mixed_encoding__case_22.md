---
title: "Mixed Encoding 22"
id: mixed_encoding_22
md_flavor: commonmark
allows_html: false
note: i18n-longline
---
