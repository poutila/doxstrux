---
title: "Math Heavy 20"
id: math_heavy_20
md_flavor: math
allows_html: false
note: latex-mix
---
