# overlapping bundle (30 pairs)
