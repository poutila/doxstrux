{"title":"Refactored code 01","id":"ref_code_01","note":"code-case"}
# Refactored code 01
Title
=====

Sub
----


```js
print('x')
```


~~~json
echo hello
~~~


Text with `inline` code and ``weird`` backticks.

```yaml
k: v
  z: [  # unclosed fence below
