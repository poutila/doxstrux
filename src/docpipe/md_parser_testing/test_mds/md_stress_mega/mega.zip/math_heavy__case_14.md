---
title: "Math Heavy 14"
id: math_heavy_14
md_flavor: math
allows_html: false
note: latex-mix
---
