---
title: "HTML Chaos 08"
id: html_chaos_08
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
