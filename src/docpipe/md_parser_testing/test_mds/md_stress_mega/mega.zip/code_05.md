{"title":"Refactored code 05","id":"ref_code_05","note":"code-case"}
# Refactored code 05
Title
=====

Sub
----


```html
print('x')
```


~~~json
echo hello
~~~


Text with `inline` code and ``weird`` backticks.

```yaml
k: v
  z: [  # unclosed fence below
