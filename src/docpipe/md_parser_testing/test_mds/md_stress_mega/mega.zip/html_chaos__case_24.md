---
title: "HTML Chaos 24"
id: html_chaos_24
md_flavor: html
allows_html: true
note: sanitization+unterminated
---
