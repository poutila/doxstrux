---
title: "Math Heavy 01"
id: math_heavy_01
md_flavor: math
allows_html: false
note: latex-mix
---
