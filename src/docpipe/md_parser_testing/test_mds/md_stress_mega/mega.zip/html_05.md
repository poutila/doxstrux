+++
title = "Refactored html 05"
id = "ref_html_05"
note = "html-case"
+++
# Refactored html 05

<div><em>ok</em></div><span style='color:red'>inline</span>

<span>inline HTML</span> paragraph.
