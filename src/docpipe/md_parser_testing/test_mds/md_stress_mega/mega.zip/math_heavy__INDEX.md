# math_heavy bundle (30 pairs)
