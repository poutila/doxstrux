# mixed_encoding bundle (30 pairs)
