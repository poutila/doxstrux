---
title: "Math Heavy 24"
id: math_heavy_24
md_flavor: math
allows_html: false
note: latex-mix
---
